% �T�u�V�X�e����I��������A���s���Ă��������B
function addGroundTerm(name)

% �u���b�N���Ȃ����ĂȂ�line���폜
hHandle = get_param(name,'LineHandles');
for i=1:length(hHandle.Inport)
    if hHandle.Inport(i) == -1
        continue;
    end
    
    if get_param(hHandle.Inport(i),'SrcBlockHandle') == -1
        delete_line(hHandle.Inport(i));
    end
end

for i=1:length(hHandle.Outport)
    if hHandle.Outport(i) == -1
        continue;
    end
    
    if get_param(hHandle.Outport(i),'DstBlockHandle') == -1
        delete_line(hHandle.Outport(i));
    end
end


hPort = get_param(name,'PortHandles');
pc = get_param(name,'PortConnectivity');

for i=1:length(pc)
    if ~isempty(pc(i).SrcBlock)% ����
        if pc(i).SrcBlock ~= -1
            continue;
        end
    else % �o��
        if ~isempty(pc(i).DstBlock)
            continue;
        end
    end
    
    pos = pc(i).Position;
    
    bh = 0;
    if ~isempty(pc(i).SrcBlock)% ����
        bh = add_block('simulink/Sources/Ground', strcat(gcs,'/Ground'),'MakeNameUnique', 'on');
    else % �o��
        bh = add_block('simulink/Sinks/Terminator', strcat(gcs,'/Ground'),'MakeNameUnique', 'on');
    end
    set_param(bh,'ShowName','off');
    
    offsetX = 50; % �ǂꂾ�������Ēu����
    blockSizeX = 20; % �u���b�N�T�C�Y
    if ~isempty(pc(i).SrcBlock)% ����
        set_param(bh,'Position',[pos(1)-offsetX-blockSizeX/2 pos(2)-blockSizeX/2 pos(1)-offsetX+blockSizeX/2 pos(2)+blockSizeX/2]);
        add_line(gcs,[pos(1)-offsetX+blockSizeX/2 pos(2);pos(1) pos(2)]);
    else % �o��
        set_param(bh,'Position',[pos(1)+offsetX-blockSizeX/2 pos(2)-blockSizeX/2 pos(1)+offsetX+blockSizeX/2 pos(2)+blockSizeX/2]);
        add_line(gcs,[pos(1) pos(2);pos(1)+offsetX-blockSizeX/2 pos(2)]);
    end
end
end

