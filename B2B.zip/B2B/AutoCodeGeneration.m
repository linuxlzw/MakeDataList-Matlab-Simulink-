% �R�[�h�����p�X�N���v�g
function AutoCodeGeneration(target)

% �����ݒ�
if exist('CodeGenFolder')
%     rmpath('CodeGenFolder');
%     rmdir('CodeGenFolder', 's');
end
mkdir('CodeGenFolder');
addpath(strcat(pwd, '/../../Common'));
addpath(strcat(pwd, '/../../Common/B2B'));
addpath(strcat(pwd, '/../../../Charger/model/Charger/Common')); %add path for SWC_03_02_CHPC_CalcPower

% copyfile('../../../../TestEnv/src/dummy_include/OBC_Variant.h', 'OBC_Variant.h');
% copyfile('../../../../TestEnv/src/dummy_include/OBC_common_define.h', 'OBC_common_define.h');
% copyfile('../../../../TestEnv/src/dummy_include/OBC_common_type.h', 'OBC_common_type.h');

run('../BaseDataDefine.m');
run('../OBC_Data.m');
run('../OBC_Type.m');

% rtwbuild�Ń��f���𑊑΃p�X�Ŏw�肷��Ɖ��̂��G���[�œ{����̂Ńf�B���N�g��
% �ړ�����`�ŉ��ō쐬�B

[path_name, model_name] = getPathModelName(target);
model_number = size(path_name, 1);
model_number = model_number(1, 1);
error_info_acg = '';

for i = 1: model_number
    try
	cur_dir = pwd;
	if (strncmp(char(path_name(i, 1)), 'SWA', 3)==1)
		path_offset = '../../../Charger/model/Charger/';
	else
		path_offset = '../../';
	end
    	cd(strcat(path_offset, char(path_name(i, 1))));
%     disp(pwd);
    load_system(char(model_name(i, 1))); % ���f�����J���Ă��Ȃ��Ǝ��s��ConfigParam���ǂ߂Ȃ��̂ŊJ��
    tmpPath = sprintf('%s/config_param_ert_sil_4_2.m', cur_dir);
    Simulink.BlockDiagram.loadActiveConfigSet(char(model_name(i, 1)), tmpPath)
    tmpPath = sprintf('%s/CodeGenFolder', cur_dir)
    Simulink.fileGenControl('set', 'CacheFolder', tmpPath, 'CodeGenFolder', tmpPath, 'keepPreviousPath', true, 'createDir', true)
    rtwbuild(char(model_name(i, 1))); % �r���h(�R�[�h����)���s
%     save_system(char(model_name(1,i))); % ConfigParam�Ǎ���ύX
    close_system(char(model_name(i, 1)), 0); % ���f�������
    if (strncmp(target, 'SWA', 3)==1)
        sils_name = sprintf('../../../../../SWE4_Unit_Verification/TestEnv/model/Charger/%s/SILS_%s', char(path_name(i, 1)), char(model_name(i, 1)));
    else
        sils_name = strcat('SILS_', char(model_name(i, 1)));
    end
    save_system('untitled', sils_name);
    close_system(sils_name);
    catch
%         disp(strcat('[ERRORINFO]', path_name(i, 1), '/', model_name(i, 1)))
%     error_info_acg = [error_info_acg; {strcat('[asdfERRORINFO] ', path_name(i, 1), '/', model_name(i, 1))}];
    end
    cd(cur_dir); % ���̊K�w�ɖ߂�
end

if strcmp(target, 'SWC')==1
	errinfo_file = 'error_info_acg.txt'
else
	errinfo_file = strcat('error_info_acg_', char(target), '.txt');
end

fp = fopen(errinfo_file, 'w');
for i = 1 : size(error_info_acg, 1)
    error_line = sprintf('%s\n', error_info_acg{i, 1}{1, 1});
    fprintf(fp, error_line);
end
fclose(fp);

'***** �����I�� *****'

end
