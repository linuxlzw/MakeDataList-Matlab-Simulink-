%% Workaround for TEMP_FaultDetection

cd('../../SWC_07_03_TEMP_FaultDetection');
model_name = 'TEMP_FaultDetection';

slx_bak_name = 'TEMP_FaultDetection.run_Test_Bak.slx';
slx_name = 'TEMP_FaultDetection.slx';
testdata_bak_name = 'TEMP_FaultDetection_TestData.run_Test_Bak.xlsx';
testdata_name = 'TEMP_FaultDetection_TestData.xlsx';

% Backup original files (�t�@�C������ϐ��Ŏw�肷��ƃG���[�ɂȂ�)
copyfile(slx_name, slx_bak_name); % 'TEMP_FaultDetection.slx' 'TEMP_FaultDetection.run_Test_Bak.slx'
copyfile(testdata_name, testdata_bak_name); % 'TEMP_FaultDetection_TestData.xlsx' 'TEMP_FaultDetection_TestData.run_Test_Bak.xlsx'

% Patch Model: Overwrite DrivingTime From 30minutes To 1minutes (180000 -> 6000)
open_system(model_name);
set_param('TEMP_FaultDetection/TEMP_FaultDetection/Check_DrivingTime/Constant','Value','6000');
save_system(model_name, [], 'OverwriteIfChangedOnDisk', true);
close_system(model_name, 1);
disp(sprintf('%s: Change DrivingTime Threshold from %d to %d, Original File is backuped as %s', slx_name, 180000, 6000, slx_bak_name));

% Patch TestData: Overwrite DrivingTime From 30minutes To 10seconds (1800 -> 60)
xlswrite('TEMP_FaultDetection_TestData.xlsx',{'60'},'TEMPSnr_15','AH2');
disp(sprintf('%s: Change DrivingTime Threshold from %d to %d, Original file is backuped as %s', testdata_name, 1800, 60, testdata_bak_name));

cd('../Common/B2B');

