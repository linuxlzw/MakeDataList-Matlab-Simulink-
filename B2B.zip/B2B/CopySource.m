function CopySource(target)

% ���f���t�@�C��������t�H���_���̃p�X
% ���f���t�@�C����

[path_name, model_name] = getPathModelName(target);
model_number = size(path_name);
model_number = model_number(1, 1);

if exist('acg_tmp')
  rmdir('acg_tmp', 's');
end
mkdir('acg_tmp');
repo_path = './acg_tmp';

if exist(repo_path,'file')
     for i = 1: model_number
         % copy <model>.c <model>.h <model>_private.h <model>_types.h
%          src_path=['CodeGenFolder/' char(model_name(1,i)) '_ert_rtw'];
%          dest_path=[repo_path '/' char(model_name(1,i)) '/src'];
%          src_path=['CodeGenFolder/' char(model_name(i, 1)) '_sfcn_rtw'];
         src_path=['CodeGenFolder/' char(model_name(i, 1)) '_ert_rtw'];
         dest_path=[repo_path '/' char(model_name(i, 1))];

         if exist(dest_path,'file') ~= 7
             mkdir(dest_path)
         end

         src_file=[src_path '/' char(model_name(i, 1)) '.c'];
         [n,m] = copyfile(src_file, dest_path);
         if n==0
             src_file, dest_path, m
         end

         src_file=[src_path '/' char(model_name(i, 1)) '_data.c'];
         if exist(src_file)
           [n,m] = copyfile(src_file, dest_path);
           if n==0
               src_file, dest_path, m
           end
         end

         src_file=[src_path '/' char(model_name(i, 1)) '.h'];
         [n,m] = copyfile(src_file, dest_path);
         if n==0
             src_file, dest_path, m
         end

         src_file=[src_path '/' char(model_name(i, 1)) '_private.h'];
         [n,m] = copyfile(src_file, dest_path);
         if n==0
             src_file, dest_path, m
         end

         src_file=[src_path '/' char(model_name(i, 1)) '_types.h'];
         [n,m] = copyfile(src_file, dest_path);
         if n==0
             src_file, dest_path, m
         end

     end
     % copy _sharedutils
      src_path = ['CodeGenFolder/slprj/ert/_sharedutils'];
      dest_path = ['./_sharedutils'];

      src_file = [src_path '/*.h'];
      [n,m] = copyfile(src_file, dest_path);
      if n==0
          src_file, dest_path, m
      end
      src_file = [src_path '/*.c'];
      [n,m] = copyfile(src_file, dest_path);
      % no error messages
     delete('_sharedutils/rtwtypes.h');
end

'***** �����I�� *****'

end
