function [path_name, model_name] = getPathModelName(target)
	if (strncmp(target, 'SWA', 3)==1)
		[path_name, model_name] = getPathModelName_CHG(target);
	elseif (strncmp(target, 'SWC', 3)==1)
		[path_name, model_name] = getPathModelName_OBC(target);
	elseif (strncmp(target, 'Appl', 4)==1)
		[path_name, model_name] = getPathModelName_Appl(target);
	else
		[path_name, model_name] = getPathModelName_Appl('Appl');
	end
end
