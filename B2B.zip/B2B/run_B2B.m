%{
-------------------------------------------------------------------------
�w�肵�� target �̒P�̌���(MILS,B2B)�����{����
Input #1 : target
	�SSWC�̏ꍇ: 'SWC'
	�ʂ�SWC���w�肷��ꍇ: 'SWC_XX_XX' ����
	�SSWA�̏ꍇ: 'SWA'
	�ʂ�SWA���w�肷��ꍇ: 'SWA_XXX_XXX' ����
	�SAppl**Ctrl�̏ꍇ: 'Appl'
	�ʂ�Appl**Ctrl���w�肷��ꍇ: 'Appl**Ctrl' ����
Input #2 : exec_mils
	MILS�����s����ꍇ: 1
	MILS�����s���Ȃ��ꍇ: 0
Input #3 : exec_b2b
	B2B�����s����ꍇ: 1
	B2B�����s���Ȃ��ꍇ: 0
-------------------------------------------------------------------------
%}
function run_B2B(target, exec_mils, exec_b2b)

% �R�[�h�����p�X�N���v�g
%���Ԍv���J�n
start = tic;

[path_name, model_name] = getPathModelName(target);
model_number = size(path_name);
model_number = model_number(1, 1);
error_info_run = '';

% Output results on current working folder.
if strcmp(target, 'SWC')==1
	out_file = 'run_B2B_result.xlsx';
	errinfo_file = 'error_info_run.txt';
elseif strcmp(target, 'SWA')==1
	out_file = 'run_B2B_result_CHG.xlsx';
	errinfo_file = 'error_info_run_CHG.txt';
else
	out_file = strcat('run_B2B_result_', char(target), '.xlsx');
	errinfo_file = strcat('error_info_run_', char(target), '.txt');
end

Error_Stop = 0;
rnum = 5;
model_index = 1;

while true
    disp('for start');
    disp(model_index);
    index = 1;
    b2b_test_result = '';
    mils_test_result = '';
    cnum = 2;

    try
        if (strncmp(char(path_name(model_index, 1)), 'SWA', 3)==1)
            path_offset = '../../../../../SWE4_Unit_Verification/TestEnv/model/Charger/';
        else
            path_offset = '../../';
        end
        swcpath = strcat(char(path_offset), char(path_name(model_index, 1)));
        cur_dir = pwd;
        cd(swcpath);
        nameB2B = sprintf('B2B_%s_Test', char(model_name(model_index, 1)));
        nameMILS = sprintf('%s_Test', char(model_name(model_index, 1)));
        if (exec_b2b == 1)
            open_system(nameB2B);   % ���f�����J���Ă��Ȃ��Ǝ��s�ł��Ȃ�����
            open_system(nameMILS);   % ���f�����J���Ă��Ȃ��Ǝ��s�ł��Ȃ�����
        elseif (exec_mils == 1)
            open_system(nameMILS);   % ���f�����J���Ă��Ȃ��Ǝ��s�ł��Ȃ�����
        end

        while true
            disp('while');
            paramStruct.RecordCoverage  = 'off';
            paramStruct.CovModelRefEnable  = 'off';
            paramStruct.CovExternalEMLEnable = 'off';

            %
            % Prepare B2B Test
            %
            if exec_b2b == 1
                b2b_sbpath = find_system(nameB2B, 'Name', 'Signal Builder');
                b2b_sbpath_size = size(b2b_sbpath, 1);
                if (b2b_sbpath_size == 0)
                    b2b_sbpath = find_system(nameB2B, 'Name', 'Inputs');
                    b2b_sbpath_size = size(b2b_sbpath, 1);
                    if (b2b_sbpath_size == 0)
                        disp(sprintf('Signal Builder %s is not found', b2b_sbpath));
                        b2b_test_result = 'NG(SignalBuilder Not Found)';
                        break;
                    end
                end
                b2b_sbpath = char(b2b_sbpath(1));
            end

            %
            % Prepare MILS Test
            %
            if (exec_mils == 1)
                mils_sbpath = find_system(nameMILS, 'Name', 'Signal Builder');
                mils_sbpath_size = size(mils_sbpath, 1);
                if (mils_sbpath_size == 0)
                    mils_sbpath = find_system(nameMILS, 'Name', 'Inputs');
                    mils_sbpath_size = size(mils_sbpath, 1);
                    if (mils_sbpath_size == 0)
                        disp(sprintf('Signal Builder %s is not found', mils_sbpath));
                        mils_test_result = 'NG(SignalBuilder Not Found)';
                        break;
                    end
                end
                mils_sbpath = char(mils_sbpath(1));
            end

            %
            % Exec MILS Test
            %
            disp(index);
            if (exec_mils == 1)
                disp(mils_sbpath);
                try
                    disp('try');
                    signalbuilder(mils_sbpath, 'activegroup', index);
                catch
                    disp(sprintf('%s: end of test', nameMILS));
                    if strcmp(mils_test_result, '') == 1
                        mils_test_result = 'OK';
                    end
                    break;
                end
                try
                    SWCTest_UseAssert = 1;
                    disp('sim');
                    sim(nameMILS, paramStruct);
                    mils_test_result = [mils_test_result, sprintf('index:%d=OK. ', index)];
                catch
                    disp('break Error');
                    mils_test_result = [mils_test_result, sprintf('index:%d=NG. ', index)];
                    SWC = sprintf('%s', nameMILS);
                    disp(SWC);
                    Error_Stop = 1;
%                   break;
                end
            end

            %
            % Exec B2B Test
            %
            if (exec_b2b == 1)
                disp(b2b_sbpath);
                try
                    disp('try');
                    signalbuilder(b2b_sbpath, 'activegroup', index);
                catch
                    disp(sprintf('%s: end of test', nameB2B));
                    if strcmp(b2b_test_result, '') == 1
                        b2b_test_result = 'OK';
                    end
                    break;
                end
                try
                    SWCTest_UseAssert = 1;
                    disp('sim');
                    sim(nameB2B, paramStruct);
                    b2b_test_result = [b2b_test_result, sprintf('index:%d=OK. ', index)];
                catch
                    disp('break Error');
                    b2b_test_result = [b2b_test_result, sprintf('index:%d=NG. ', index)];
                    SWC = sprintf('%s', nameB2B);
                    disp(SWC);
                    Error_Stop = 1;
%                   break;
                end
            end

            disp('while loop');
            index = index + 1;
        end

        if (exec_b2b == 1)
            bdclose(nameB2B);
            bdclose(nameMILS);
        elseif (exec_mils == 1)
            bdclose(nameMILS);
        end
        cd(cur_dir); % ���̊K�w�ɖ߂�

        %�t�@�C���o��
        excelsheet = 'run_B2B';                      %%�V�[�g����
        xlRange = sprintf('A%d', rnum);      %%�Z���̔ԍ�
        temp_path_name = char(path_name(model_index, 1));
        if strncmp(temp_path_name, 'SWC', 3)==1
            temp_path_name = temp_path_name(1:9);  % 'SWC_XX_XX' ��9����
        else
            temp_path_name = temp_path_name(1:11);  % 'SWA_XXX_XXX' ��11����
        end
        outinfo = {char(temp_path_name)};    %%�o�͏��i���f�����́j
        xlswrite(out_file,outinfo,excelsheet,xlRange) %%�G�N�Z���t�@�C���ւ̏����o��
        xlRange = sprintf('B%d', rnum);      %%�Z���̔ԍ�
        outinfo = {char(model_name(model_index, 1))};    %%�o�͏��i���f�����́j
        xlswrite(out_file,outinfo,excelsheet,xlRange) %%�G�N�Z���t�@�C���ւ̏����o��
        cnum= cnum + 1;
        if (exec_b2b == 1)
            xlRange = sprintf('C%d', rnum);      %%�Z���̔ԍ�
            outinfo = {b2b_test_result};                        %%�o�͏��iB2B���ʁFOK/NG�j
            xlswrite(out_file,outinfo,excelsheet,xlRange) %%�G�N�Z���t�@�C���ւ̏����o��
        end
        if (exec_mils == 1)
            xlRange = sprintf('D%d', rnum);      %%�Z���̔ԍ�
            outinfo = {mils_test_result};                        %%�o�͏��iMILS���ʁFOK/NG�j
            xlswrite(out_file,outinfo,excelsheet,xlRange) %%�G�N�Z���t�@�C���ւ̏����o��
        end
        rnum = rnum + 1;
        if (model_number == model_index)
            break;
        end
        model_index = model_index + 1;
    
    catch
        disp(strcat('[ERRORINFO]', path_name(model_index, 1), '/', model_name(model_index, 1)))
        error_info_run = [error_info_run; {strcat('[ERRORINFO] ', path_name(model_index, 1), '/', model_name(model_index, 1))}];
        mils_test_result = [mils_test_result, sprintf('Abnormal finished because error occurred in MILS running. ')];
        b2b_test_result = [b2b_test_result, sprintf('Abnormal finished because error occurred in B2B running. ')];

        if (exec_b2b == 1)
            bdclose(nameB2B);
            bdclose(nameMILS);
        elseif (exec_mils == 1)
            bdclose(nameMILS);
        end
        cd(cur_dir); % ���̊K�w�ɖ߂�
 
        %�t�@�C���o��
        excelsheet = 'run_B2B';                      %%�V�[�g����
        xlRange = sprintf('A%d', rnum);      %%�Z���̔ԍ�
        temp_path_name = char(path_name(model_index, 1));
        if strncmp(temp_path_name, 'SWC', 3)==1
            temp_path_name = temp_path_name(1:9);  % 'SWC_XX_XX' ��9����
        else
            temp_path_name = temp_path_name(1:11);  % 'SWA_XXX_XXX' ��11����
        end
        outinfo = {char(temp_path_name)};    %%�o�͏��i���f�����́j
        xlswrite(out_file,outinfo,excelsheet,xlRange) %%�G�N�Z���t�@�C���ւ̏����o��
        xlRange = sprintf('B%d', rnum);      %%�Z���̔ԍ�
        outinfo = {char(model_name(model_index, 1))};    %%�o�͏��i���f�����́j
        xlswrite(out_file,outinfo,excelsheet,xlRange) %%�G�N�Z���t�@�C���ւ̏����o��
        cnum= cnum + 1;
        if (exec_b2b == 1)
            xlRange = sprintf('C%d', rnum);      %%�Z���̔ԍ�
            outinfo = {b2b_test_result};                        %%�o�͏��iB2B���ʁFOK/NG�j
            xlswrite(out_file,outinfo,excelsheet,xlRange) %%�G�N�Z���t�@�C���ւ̏����o��
        end
        if (exec_mils == 1)
            xlRange = sprintf('D%d', rnum);      %%�Z���̔ԍ�
            outinfo = {mils_test_result};                        %%�o�͏��iMILS���ʁFOK/NG�j
            xlswrite(out_file,outinfo,excelsheet,xlRange) %%�G�N�Z���t�@�C���ւ̏����o��
        end
        rnum = rnum + 1;
        if (model_number == model_index)
            break;
        end
        model_index = model_index + 1;
    end
end

fp = fopen(errinfo_file, 'w');
for i = 1 : size(error_info_run, 1)
    error_line = sprintf('%s\n', char(error_info_run{i, 1}{1, 1}));
    fprintf(fp, error_line);
end
fclose(fp);

toc(start)

'***** �����I�� *****'

end
