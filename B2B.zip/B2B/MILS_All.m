ApplyPatch;
%acg_script('Appl');
%make_B2Benv('Appl');
run_B2B('Appl', 1, 0);
RemovePatch;
