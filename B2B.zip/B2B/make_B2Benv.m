% B2B���p�X�N���v�g
function make_B2Benv(target)

fileName  = 'B2Benv_Assert.m';
fileName2 = 'addGroundTerm.m';
fileName3 = 'alignOutport.m';
disp(fileName);
disp(fileName2);

[path_name, model_name] = getPathModelName(target);
model_number = size(path_name);
model_number = model_number(1, 1);
error_info_assert = '';
cur_dir = pwd;

filePlace  = sprintf('%s/%s', cur_dir, fileName);
filePlace2 = sprintf('%s/%s', cur_dir, fileName2);
filePlace3 = sprintf('%s/%s', cur_dir, fileName3);

disp(filePlace);
disp(filePlace2);
disp(filePlace3);

for i = 1: model_number
    try
	if (strncmp(char(path_name(i, 1)), 'SWA', 3)==1)
		path_offset = '../../../../../SWE4_Unit_Verification/TestEnv/model/Charger/';
	else
		path_offset = '../../';
	end
    cd(strcat(path_offset, char(path_name(i, 1))));
    copyfile(filePlace, './');
    copyfile(filePlace2, './');
    copyfile(filePlace3, './');
    B2Benv_Assert(char(model_name(i, 1)));
    catch
%         disp(strcat('[ERRORINFO]', path_name(i, 1), '/', model_name(i, 1)))
        error_info_assert = [error_info_assert; {strcat('[ERRORINFO] ', path_name(i, 1), '/', model_name(i, 1))}];
    end
    delete(fileName);
    delete(fileName2);
    delete(fileName3);
    cd(cur_dir); % ���̊K�w�ɖ߂�
end

fp = fopen('error_info_assert.txt', 'w');
for i = 1 : size(error_info_assert, 1)
    error_line = sprintf('%s\n', error_info_assert{i, 1}{1, 1});
    fprintf(fp, error_line);
end
fclose(fp);

'***** �����I�� *****'

end
