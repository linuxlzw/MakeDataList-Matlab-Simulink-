%% Workaround for TEMP_FaultDetection

cd('../../SWC_07_03_TEMP_FaultDetection');
model_name = 'TEMP_FaultDetection';

slx_bak_name = 'TEMP_FaultDetection.run_Test_Bak.slx';
slx_name = 'TEMP_FaultDetection.slx';
testdata_bak_name = 'TEMP_FaultDetection_TestData.run_Test_Bak.xlsx';
testdata_name = 'TEMP_FaultDetection_TestData.xlsx';

[status,msg,msgId] = copyfile(slx_bak_name, slx_name);
if (status == 0)
	disp(sprintf('%s: %s', slx_name, char(msg)));
	open_system(model_name);
	set_param('TEMP_FaultDetection/TEMP_FaultDetection/Check_DrivingTime/Constant','Value','180000');
	save_system(model_name, [], 'OverwriteIfChangedOnDisk', true);
	close_system(model_name, 1);
	disp(sprintf('%s: Restore DrivingTime Threshold [%d]', slx_name, 180000));
	disp(sprintf('Please rename %s to %s manually', slx_bak_name, slx_name));
else
	disp(sprintf('%s: Restore backup file successfully', slx_name));
	delete 'TEMP_FaultDetection.run_Test_Bak.slx'; %�t�@�C������ϐ��Ŏw�肷��ƃG���[�ɂȂ�
end

[status,msg,msgId] = copyfile(testdata_bak_name, testdata_name);
if (status == 0)
	disp(sprintf('%s: %s', testdata_name. char(msg)));
	xlswrite('TEMP_FaultDetection_TestData.xlsx',{'1800'},'TEMPSnr_15','AH2');
	disp(sprintf('%s: Restore DrivingTime Threshold [%d]', testdata_name, 1800));
	disp(sprintf('Please rename %s to %s manually', testdata_bak_name, testdata_name));
else
	disp(sprintf('%s: Restore backup file successfully', testdata_name));
	delete(testdata_bak_name); %'TEMP_FaultDetection_TestData.run_Test_Bak.xlsx'; %�t�@�C������ϐ��Ŏw�肷��ƃG���[�ɂȂ�
end

cd('../Common/B2B');

