
% cd ../src/AUTOSAR_ENV/OBC/Appl/Source/Application
if exist('acg_new')
  rmdir('acg_new', 's');
end
mkdir('acg_new');
% cd ../../../../../../model

% dos('prep_build');

% rmdir('acg_tmp','s');

'***** �����I�� *****'
