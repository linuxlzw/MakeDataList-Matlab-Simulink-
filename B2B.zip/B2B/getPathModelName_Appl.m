%{
-------------------------------------------------------------------------
Function :
 Appl**Ctrl�Ώۂ�Model�ꗗ���擾����
Input : 'Appl', 'ApplCplCtrl', 'ApplEvseCtrl', ... 
Output : Model Names
-------------------------------------------------------------------------
%}
function [path_name, model_name] = getPathModelName_Appl(target)
    cur_dir = cd('../..');
    req_key = sprintf('*%s*', char(target));
	dir_list_tmp = dir(char(req_key));
	num = size(dir_list_tmp, 1);

	path_name = cell(0, 1);
	model_name = cell(0, 1);
	for dir_list_tmp_idx=1:num
		[path_name_sub, model_name_sub] = getPathModelName_ApplSub(char(dir_list_tmp(dir_list_tmp_idx).name));
		path_name = vertcat(path_name, path_name_sub);
		model_name = vertcat(model_name, model_name_sub);
	end
    cd(cur_dir);
    
    if strcmp(target, 'ApplHvCtrl') == 1
        cur_dir = cd('../../../Charger/model/Charger');
        [path_name_sub, model_name_sub] = getPathModelName_Chrger1ms();
		path_name = vertcat(path_name, path_name_sub);
		model_name = vertcat(model_name, model_name_sub);
        cd(cur_dir);
    end
end



%{
-------------------------------------------------------------------------
Function :
 Appl**Ctrl�Ώۂ�Model�ꗗ���擾����
Input : 'ApplCplCtrl', 'ApplEvseCtrl', ... 
Output : Model Names ('SWC_XX_XX')
-------------------------------------------------------------------------
%}
function [path_name, model_name] = getPathModelName_ApplSub(appl)
    	xlsname1 = strcat(char(appl), '/Make_SWC_', char(appl), '.xlsx');
    	xlsname2 = strcat(char(appl), '/INTEG_', char(appl), '.xlsx');

    	if (exist(char(xlsname1), 'file') ==2)
        	[num, txt, raw] = xlsread(char(xlsname1), 'ScheduleData');
    	elseif (exist(char(xlsname2), 'file') ==2)
        	[num, txt, raw] = xlsread(char(xlsname2), 'ScheduleData');
    	else
       		raw = [];
    	end
    
	szraw = size(raw,1);
	runnables = raw(3:szraw);
	szrunnables = size(runnables,2);
  
    	if (strcmp(char(appl), 'ApplHvCtrl'))
        	% Runnable_Chrger_1ms�����O����
        	model_id = cell(szrunnables-1, 1);
    	else
        	model_id = cell(szrunnables, 1);
    	end
	kdx = 1;
	for idx = 1 : szrunnables
		tmp = strsplit(char(runnables(idx)), '_');
		nametmp = '';
		for jdx = 2 : size(tmp,2)
   			if jdx==2
   				nametmp = tmp{jdx} ;
   			else
       			nametmp = strcat(nametmp,'_',tmp{jdx});
   			end
       	end
       	% Runnable_Chrger_1ms�����O����
		if strcmp(tmp{2}, 'SWC')==1
			model_id{kdx, 1} = nametmp;
			kdx = kdx + 1;
		end
	end

	model_num = size(model_id, 1);
	path_name = cell(model_num, 1);
	model_name = cell(model_num, 1);
	for idx = 1 : model_num
		req_key = sprintf('*%s*', char(model_id{idx, 1}));
		dir_list_tmp = dir(char(req_key));
		num = size(dir_list_tmp, 1);
		if num ~= 0
			path_name{idx, 1} = char(dir_list_tmp(1).name);
			model_name{idx, 1} = get_model_name(dir_list_tmp(1).name);
		end
	end
end


%{
-------------------------------------------------------------------------
Function :
 Runnable_Chrger_1ms�Ɍ�������Ă���SWA Model�ꗗ���擾����
Input : �Ȃ� 
Output : Model Names ('SWA_XXX_XXX')
-------------------------------------------------------------------------
%}
function [path_name, model_name] = getPathModelName_Chrger1ms()
    	xlsname = 'SWC_SLE_Mbd_for_OBC/Make_SWC_SLE_design.xlsx';

    	if (exist(char(xlsname), 'file') ==2)
        	[num, txt, raw] = xlsread(char(xlsname), 'ScheduleData');
    	else
       		raw = [];
    	end
    
	szraw = size(raw,1);
    % Runnable,Scheduler,SWIT_Pre_Process, SWIT_Post_Process�����O
	runnables = raw(4:szraw);
	szrunnables = size(runnables,1)-1;
 
   	model_id = cell(szrunnables, 1);
 
	for idx = 1 : szrunnables
		tmp = strsplit(char(runnables(idx)), '_');
		nametmp = '';
		for jdx = 2 : size(tmp,2)
   			if jdx==2
   				nametmp = tmp{jdx} ;
   			else
      			nametmp = strcat(nametmp,'_',tmp{jdx});
   			end
        end
		model_id{idx, 1} = nametmp;
	end

	model_num = size(model_id, 1);
	path_name = cell(model_num, 1);
	model_name = cell(model_num, 1);
	for idx = 1 : model_num
		req_key = sprintf('*%s*', char(model_id{idx, 1}));
		dir_list_tmp = dir(char(req_key));
		num = size(dir_list_tmp, 1);
		if num ~= 0
			path_name{idx, 1} = char(dir_list_tmp(1).name);
			model_name{idx, 1} = get_model_name(dir_list_tmp(1).name);
		end
	end
end


%{
-------------------------------------------------------------------------
Function :
 ���f���̃t�@�C���p�X����Model�����擾����
Input : Model Path(Relative)
Output : Model Name
-------------------------------------------------------------------------
%}
function model_name = get_model_name(path)
	tmp = strsplit(path,'_');
	model_name = '';
	for jdx = 4 : size(tmp,2)
    		if jdx==4
       			model_name = tmp{jdx} ;
    		else
        		model_name = strcat( model_name,'_',tmp{jdx});
    		end
	end
end


