function B2Benv_Assert(name)
    nameB2B = sprintf('B2B_%s_Test', name);
    nameSFunc = sprintf('SILS_%s', name);

    %���łɍ쐬�ς݂̏ꍇ�̓t�@�C������_�����đޔ�����
    slxTmp = sprintf('%s.slx', nameB2B);
    if exist(slxTmp, 'file')
%         eval(sprintf('!move /Y %s %s_.slx', fnTmp, nameB2B));
        movefile(slxTmp, strcat('__', slxTmp));
    end
    cmdTmp = sprintf('%s_Cmd.m', nameB2B);
    if exist(cmdTmp, 'file')
        movefile(cmdTmp, strcat('__', cmdTmp));
    end

    load_system(name);
    %���f���̓��̓|�[�g��/�o�̓|�[�g���̃J�E���g
    pathIn = find_system(name, 'SearchDepth', 1, 'BlockType', 'Inport');
    numIn = numel(pathIn);
    pathOut = find_system(name, 'SearchDepth', 1, 'BlockType', 'Outport');
    numOut = numel(pathOut);

    %B2B�p�̌��؃t�@�C�����쐬
    copyfile(sprintf('%s_Test.slx',name), sprintf('%s.slx', nameB2B));
    copyfile(sprintf('%s_Test_Cmd.m', name), sprintf('%s_Cmd.m', nameB2B));

    %B2B�p���ؐݒ�t�@�C���̍쐬(_Cmd�t�@�C���̓��e���ꕔ�u��)
    ID = fopen(sprintf('%s_Cmd.m', nameB2B),'w','n','Shift_JIS');
    ID2 = fopen(sprintf('%s_Test_Cmd.m', name),'r','n','Shift_JIS');
    tline = fgetl(ID2);
    while ischar(tline)
        abc = strrep(tline, sprintf('%s_Test/', name), sprintf('%s/', nameB2B));
        if strcmp(abc, tline)
            abc = strrep(tline, 'strcat(modelName, ''_Test/InputData/Signal Builder'')', 'strcat(''B2B_'', modelName, ''_Test/InputData/Signal Builder'')');
        end
        fprintf(ID, '%s\r\n', abc);
        tline = fgetl(ID2);
    end
    fclose(ID);
    fclose(ID2);

    open_system(nameB2B);

    % �R�[���o�b�N�̐ݒ�
    PreloadFcnSet = get_param(nameB2B,'PreLoadFcn');
    PathName      = '''../Common/B2B/CodeGenFolder'''
    PreloadFcnSet = sprintf('addpath(%s);\n%s', PathName, PreloadFcnSet);
    set_param(nameB2B,'PreLoadFcn',PreloadFcnSet);
    InitFcnSet = get_param(nameB2B,'InitFcn');
    InitFcnSet = strrep(InitFcnSet, sprintf('%s_Test', name), nameB2B);
    set_param(nameB2B,'InitFcn',InitFcnSet);
    PostLoadFcnSet = get_param(nameB2B,'PostLoadFcn');
    PostLoadFcnSet = strrep(PostLoadFcnSet, sprintf('%s_Test', name), nameB2B);
    set_param(nameB2B,'PostLoadFcn',PostLoadFcnSet);
    
    % Assert�����ׂėL��
    set_param(nameB2B, 'AssertControl', 'EnableAll');

    % Generated S-Function�̈ʒu�ݒ�
    model_posi      = get_param(sprintf('%s/FunctionCall/Model', nameB2B),'Position');
    b2b_S_Func_posi    = model_posi;
    b2b_S_Func_posi(2) = model_posi(4) + 100;
    b2b_S_Func_posi(4) = b2b_S_Func_posi(2) + model_posi(4) - model_posi(2);

    % Generated S-Function�̒ǉ�
%     add_block('rtwlib/S-Function Target/Generated S-Function', sprintf('%s/FunctionCall/Generated S-Function', nameB2B),...
%         'Position', b2b_S_Func_posi,...
%         'rtw_sf_name', sprintf('%s_sf', name));
    load_system(nameSFunc);
%     add_block(sprintf('%s/Generated S-Function', nameSFunc), sprintf('%s/FunctionCall/Generated S-Function', nameB2B),...
%         'Position', b2b_S_Func_posi);
    add_block(sprintf('%s/%s', nameSFunc, name), sprintf('%s/FunctionCall/%s', nameB2B, name),...
        'Position', b2b_S_Func_posi);
    close_system(nameSFunc);

    %���̓f�[�^��Generated S-Function��ڑ�����
    InputPort = find_system(sprintf('%s/FunctionCall', nameB2B), 'SearchDepth', 1, 'BlockType', 'Inport');
    for portNo = 1:numIn
        for ii = 1:numIn
            nameIn = char(InputPort{ii});
            InpotrNum = get_param(nameIn, 'Port'); %���̓|�[�g���ɒB������break
            if portNo == str2double(InpotrNum)
                break;
            end
        end
%          add_line(sprintf('%s/FunctionCall', nameB2B), sprintf('%s/1', get_param(nameIn, 'name')), sprintf('Generated S-Function/%d', portNo), 'autorouting','on');
        add_line(sprintf('%s/FunctionCall', nameB2B), sprintf('%s/1', get_param(nameIn, 'name')), sprintf('%s/%d', name, portNo), 'autorouting','on');
    end

    %�o�̓|�[�g��Generated S-Function��ڑ�����
    OutputPort = find_system(sprintf('%s/FunctionCall', nameB2B), 'SearchDepth', 1, 'BlockType', 'Outport');
    numOut = numel(pathOut);

    for portNo = 1:numOut
        for ii = 1:numOut
            nameOut = char(OutputPort{ii});
            n = get_param(nameOut, 'Port'); %�o�̓|�[�g���ɒB������break
            if portNo == str2double(n)
                break;
            end
        end

         % �o�̓|�[�g�̈ʒu���擾
         out_port_posi = get_param(nameOut,'Position');
         b2b_port_posi = out_port_posi;
         b2b_port_posi(2) = b2b_port_posi(2) + b2b_S_Func_posi(2) - model_posi(2); %��
         b2b_port_posi(4) = b2b_port_posi(4) + b2b_S_Func_posi(2) - model_posi(2); %��
   
         % �o�̓|�[�g��ǉ�
         add_block('simulink/Commonly Used Blocks/Out1', sprintf('%s/FunctionCall/Out%d', nameB2B, portNo),...
             'Position', b2b_port_posi,...
             'Name', sprintf('B2B_%s', get_param(nameOut, 'name')));

%          add_line(sprintf('%s/FunctionCall', nameB2B), sprintf('Generated S-Function/%d', portNo), sprintf('B2B_%s/1', get_param(nameOut, 'name')), 'autorouting','on');
        add_line(sprintf('%s/FunctionCall', nameB2B), sprintf('%s/%d', name, portNo), sprintf('B2B_%s/1', get_param(nameOut, 'name')), 'autorouting','on');
    end

    %OutputData���폜����
    h = get_param(sprintf('%s/OutputData', nameB2B),'LineHandles');
    delete_line(h.Inport)
    delete_block(sprintf('%s/OutputData', nameB2B));

    %FunctionCall�̈ʒu�擾
    FunctionCallPosi = get_param(sprintf('%s/FunctionCall', nameB2B), 'Position');

    for ii = 1:numOut
        %Assertion�̒ǉ�
        add_block('simulink/Model Verification/Assertion', sprintf('%s/Assertion%d', nameB2B, ii));
        RPosi = get_param(sprintf('%s/Assertion%d', nameB2B, ii), 'Position');
        %�c����
        RPosi(2) = FunctionCallPosi(2) + 5 + ii * 40 - 40;
        RPosi(4) = FunctionCallPosi(2) + 5 + ii * 40 - 40 + 30;
        %������
        RPosi(1) = FunctionCallPosi(3) + 300 + (ii - 1) * 50;
        RPosi(3) = FunctionCallPosi(3) + 300 + 50 + (ii - 1) * 50;;
        set_param(sprintf('%s/Assertion%d', nameB2B, ii), 'Position', RPosi);

        %RelationalOperator�̒ǉ�
        add_block('built-in/RelationalOperator', sprintf('%s/R%d', nameB2B, ii),...
            'ShowName', 'off',...
            'Operator', '==');
        RPosi = get_param(sprintf('%s/R%d', nameB2B, ii), 'Position');
        %�c����
        RPosi(2) = FunctionCallPosi(2) + 2 + ii * 40 - 40;
        RPosi(4) = FunctionCallPosi(2) + 2 + ii * 40 - 40 + 30;
        %������
        RPosi(1) = FunctionCallPosi(3) + 100+ (ii - 1) * 50;
        RPosi(3) = FunctionCallPosi(3) + 100 + 30+ (ii - 1) * 50;
        set_param(sprintf('%s/R%d', nameB2B, ii), 'Position', RPosi);
        add_line(nameB2B, sprintf('R%d/1', ii), sprintf('Assertion%d/1', ii), 'autorouting','on');
    end

    %RelationalOperator�ƃ��f���̐���ڑ�����
    for portNo = 1:numOut
        for ii = 1:numOut
            nameOut = char(OutputPort{ii});
            n = get_param(nameOut, 'Port'); %�o�̓|�[�g���ɒB������break
            if portNo == str2double(n)
                break;
            end
        end
         add_line(nameB2B, sprintf('FunctionCall/%d', portNo), sprintf('R%d/1', portNo), 'autorouting','on');
         add_line(nameB2B, sprintf('FunctionCall/%d', portNo+numOut), sprintf('R%d/2', portNo), 'autorouting','on');
    end

    %RelationalOperator��Assertion�̈ʒu���킹
    alignOutport(sprintf('%s/FunctionCall', nameB2B));

    % Terminater�̐ݒu
    addGroundTerm(sprintf('%s/InputData', nameB2B));

    save_system(nameB2B);
    close_system(nameB2B);
    
    if exist(strcat('__', slxTmp), 'file')
        delete(strcat('__', slxTmp));
    end
    if exist(strcat('__', cmdTmp), 'file')
        delete(strcat('__', cmdTmp));
    end

end

