function com_write_excel_port_list(filePath, table)

    sheetName = 'PortList';
    com_create_excel_file(filePath, sheetName);

    excelColumnFirstIndex = 'A';
    excelColumnLastIndex = 'G';
    excelLineIndex = 1;
    title = {'BlockType','Port','Name','OutDataTypeStr','PortDimensions','Description','AttributesFormatString'};
    excelWriteRange = strcat(excelColumnFirstIndex, num2str(excelLineIndex), ':', excelColumnLastIndex, num2str(excelLineIndex));
    [status, message] = xlswrite(char(filePath), title, sheetName, excelWriteRange);

    excelLineIndex = excelLineIndex + 1;
    excelWriteRange = strcat(excelColumnFirstIndex, num2str(excelLineIndex), ':', excelColumnLastIndex, num2str(excelLineIndex + size(table, 1) - 1));
    [status, message] = xlswrite(char(filePath), table, sheetName, excelWriteRange);

end
