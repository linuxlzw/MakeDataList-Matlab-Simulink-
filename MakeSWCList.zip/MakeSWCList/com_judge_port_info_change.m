function isChangedFlag = com_judge_port_info_change(oldPortInfoTable, newPortInfoTable)

    global BlockTypeIndex
    global PortIndex
    global BlockNameIndex
    global OutDataTypeStrIndex
    global PortDimensionsIndex
    global DescriptionIndex
    global AttributesFormatStringIndex

    isChangedFlag = 'FALSE';
    if size(oldPortInfoTable, 1) == size(newPortInfoTable, 1)
        for i = 1 : size(newPortInfoTable, 1)
            if strcmp(oldPortInfoTable{i, BlockTypeIndex}, newPortInfoTable{i, BlockTypeIndex}) == 0
                isChangedFlag = 'TRUE';
                break;
            end
            if strcmp(oldPortInfoTable{i, PortIndex}, newPortInfoTable{i, PortIndex}) == 0
                isChangedFlag = 'TRUE';
                break;
            end
            if strcmp(oldPortInfoTable{i, BlockNameIndex}, newPortInfoTable{i, BlockNameIndex}) == 0
                isChangedFlag = 'TRUE';
                break;
            end
            if strcmp(oldPortInfoTable{i, OutDataTypeStrIndex}, newPortInfoTable{i, OutDataTypeStrIndex}) == 0
                isChangedFlag = 'TRUE';
                break;
            end
            if strcmp(oldPortInfoTable{i, PortDimensionsIndex}, newPortInfoTable{i, PortDimensionsIndex}) == 0
                isChangedFlag = 'TRUE';
                break;
            end
            if strcmp(oldPortInfoTable{i, DescriptionIndex}, newPortInfoTable{i, DescriptionIndex}) == 0
                isChangedFlag = 'TRUE';
                break;
            end
            if strcmp(oldPortInfoTable{i, AttributesFormatStringIndex}, newPortInfoTable{i, AttributesFormatStringIndex}) == 0
                isChangedFlag = 'TRUE';
                break;
            end
        end
    else
        isChangedFlag = 'TRUE';
    end

end