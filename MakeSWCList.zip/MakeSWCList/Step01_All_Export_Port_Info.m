function Step01_All_Export_Port_Info()

    workPath = pwd;
    modelListPathName = strcat(workPath, '\ModelList.csv');
    modelList = com_read_excel_model_list(modelListPathName);

    for i = 1 : size(modelList, 1)
        info = sprintf('[Info][%d/%d]Exporting ''%s''\t''%s''', i, size(modelList, 1), modelList{i, 1}, modelList{i, 2});
        disp(info);
        if strcmp(modelList{i, 3}, '1') == 1
            com_export_port_info(strcat('../../', modelList{i, 1}), modelList{i, 2}, '');
        else
            info = sprintf('[Info][%d/%d]Omit to export ''%s''\t''%s'' since DoExport flag is OFF in ModelList.csv', i, size(modelList, 1), modelList{i, 1}, modelList{i, 2});
            disp(info);
        end
    end

end

