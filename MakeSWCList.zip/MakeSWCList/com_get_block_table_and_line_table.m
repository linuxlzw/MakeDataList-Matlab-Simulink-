function [table_block, table_line, ModelReferenceInputList, ModelReferenceOutputList, ModelReferenceList, ModelReference_Name] = com_get_block_table_and_line_table(model_path, isLib)

    global BlockTableTypeIndex
    global BlockTableNameIndex

    table_block = {'BlockType','BlockName','ParamName','ParamValue'};
    table_line = {'SrcBlock','SrcPort','SrcBlockType','DstBlock','DstPort','DstBlockType','Name'};
    ModelReferenceInputList = '';
    ModelReferenceOutputList = '';
    ModelReferenceList = '';
    ModelReference_Name = '';

    write_counter_block = 2;
    write_counter_line = 2;

    if isLib == 1
        Inport = find_system(char(model_path), 'LookUnderMasks', 'all', 'FollowLinks', 'on', 'SearchDepth', '1', 'IncludeCommented', 'on', 'blocktype', 'Inport');
        Outport = find_system(char(model_path), 'LookUnderMasks', 'all', 'FollowLinks', 'on', 'SearchDepth', '1', 'IncludeCommented', 'on', 'blocktype', 'Outport');
    else
        Inport = find_system(char(model_path), 'SearchDepth', '1', 'IncludeCommented', 'on', 'blocktype', 'Inport');
        Outport = find_system(char(model_path), 'SearchDepth', '1', 'IncludeCommented', 'on', 'blocktype', 'Outport');
%         Terminator = find_system(char(model_path), 'SearchDepth', '1', 'IncludeCommented', 'on', 'blocktype', 'Terminator');
%         Ground = find_system(char(model_path), 'SearchDepth', '1', 'IncludeCommented', 'on', 'blocktype', 'Ground');
%         Convert = find_system(char(model_path), 'SearchDepth', '1', 'IncludeCommented', 'on', 'blocktype', 'DataTypeConversion');
%         Constant = find_system(char(model_path), 'SearchDepth', '1', 'IncludeCommented', 'on', 'blocktype', 'Constant');
%         BusSelector = find_system(char(model_path), 'SearchDepth', '1', 'IncludeCommented', 'on', 'blocktype', 'BusSelector');
%         BusCreator = find_system(char(model_path), 'SearchDepth', '1', 'IncludeCommented', 'on', 'blocktype', 'BusCreator');
%         Goto = find_system(char(model_path), 'SearchDepth', '1', 'IncludeCommented', 'on', 'blocktype', 'Goto');
%         From = find_system(char(model_path), 'SearchDepth', '1', 'IncludeCommented', 'on', 'blocktype', 'From');
%         Mux = find_system(char(model_path), 'SearchDepth', '1', 'IncludeCommented', 'on', 'blocktype', 'Mux');
%         Selector = find_system(char(model_path), 'SearchDepth', '1', 'IncludeCommented', 'on', 'blocktype', 'Selector');
%         Line = find_system(char(model_path), 'SearchDepth', '1','FindAll', 'on',  'type', 'line');
    end

%     ModelReference = find_system(char(model_path), 'SearchDepth', '1', 'IncludeCommented', 'on', 'blocktype', 'ModelReference');
%     num = size(ModelReference, 1);
%     for i = 1:num
%         [path, name] = com_split_path(char(ModelReference(i, 1)));
%         ModelReference_Name = name;
% 
%         ModelReferenceInput = get_param(char(ModelReference(i, 1)), 'InputPortNames');
%         ModelReferenceInputList = getPortNames(ModelReferenceInput);
% 
%         ModelReferenceOutput = get_param(char(ModelReference(i, 1)), 'OutputPortNames');
%         ModelReferenceOutputList = getPortNames(ModelReferenceOutput);
% 
%         ModelReferenceList =  [ModelReferenceInputList ModelReferenceOutputList] ;
% 
%         Ports = get_param(char(ModelReference(i, 1)), 'Ports');
%         Ports_1 = num2str(Ports(1,1));
%         Ports_2 = num2str(Ports(1,2));
%         Ports_str = [Ports_1,',',Ports_2];
%         info_block = {char('ModelReference'), char(name), char('Ports'), char(Ports_str)};
%         [table_block, write_counter_block] = write_table_block(table_block, write_counter_block, info_block);
%     end
% 
%     SubSystem = find_system(char(model_path), 'SearchDepth', '1', 'IncludeCommented', 'on', 'blocktype', 'SubSystem');
%     num = size(SubSystem, 1);
%     for i = 1:num
%         [path, name] = com_split_path(char(SubSystem(i, 1)));
%         Ports = get_param(char(SubSystem(i, 1)), 'Ports');
%         Ports_1 = num2str(Ports(1,1));
%         Ports_2 = num2str(Ports(1,2));
%         Ports_str = [Ports_1,',',Ports_2];
%         info_block = {char('SubSystem'), char(name), char('Ports'), char(Ports_str)};
%         [table_block, write_counter_block] = write_table_block(table_block, write_counter_block, info_block);
%     end

    num = size(Inport, 1);
    for i = 1:num
        [path, name] = com_split_path(char(Inport(i, 1)));
%         BusObject = get_param(char(Inport(i, 1)), 'BusObject');
%         info_block = {char('Inport'), char(name), char('BusObject'), char(BusObject)};
%         [table_block, write_counter_block] = write_table_block(table_block, write_counter_block, info_block);

        Port = get_param(char(Inport(i, 1)), 'Port');
        info_block = {char('Inport'), char(name), char('Port'), char(Port)};
        [table_block, write_counter_block] = write_table_block(table_block, write_counter_block, info_block);

        OutDataTypeStr = get_param(char(Inport(i, 1)), 'OutDataTypeStr');
        info_block = {char('Inport'), char(name), char('OutDataTypeStr'), char(OutDataTypeStr)};
        [table_block, write_counter_block] = write_table_block(table_block, write_counter_block, info_block);

        PortDimensions = get_param(char(Inport(i, 1)), 'PortDimensions');
        info_block = {char('Inport'), char(name), char('PortDimensions'), char(PortDimensions)};
        [table_block, write_counter_block] = write_table_block(table_block, write_counter_block, info_block);

        Description = get_param(char(Inport(i, 1)), 'Description');
        info_block = {char('Inport'), char(name), char('Description'), char(Description)};
        [table_block, write_counter_block] = write_table_block(table_block, write_counter_block, info_block);

        AttributesFormatString = get_param(char(Inport(i, 1)), 'AttributesFormatString');
%         if strcmp(AttributesFormatString, '') == 0
%             AttributesFormatString = strrep(AttributesFormatString, '%', '%%');
%         end
        info_block = {char('Inport'), char(name), char('AttributesFormatString'), char(AttributesFormatString)};
        [table_block, write_counter_block] = write_table_block(table_block, write_counter_block, info_block);
    end

    num = size(Outport, 1);
    for i = 1:num
        [path, name] = com_split_path(char(Outport(i, 1)));
%         BusObject = get_param(char(Outport(i, 1)), 'BusObject');
%         info_block = {char('Outport'), char(name), char('BusObject'), char(BusObject)};
%         [table_block, write_counter_block] = write_table_block(table_block, write_counter_block, info_block);

        Port = get_param(char(Outport(i, 1)), 'Port');
        info_block = {char('Outport'), char(name), char('Port'), char(Port)};
        [table_block, write_counter_block] = write_table_block(table_block, write_counter_block, info_block);

        OutDataTypeStr = get_param(char(Outport(i, 1)), 'OutDataTypeStr');
        info_block = {char('Outport'), char(name), char('OutDataTypeStr'), char(OutDataTypeStr)};
        [table_block, write_counter_block] = write_table_block(table_block, write_counter_block, info_block);

        PortDimensions = get_param(char(Outport(i, 1)), 'PortDimensions');
        info_block = {char('Outport'), char(name), char('PortDimensions'), char(PortDimensions)};
        [table_block, write_counter_block] = write_table_block(table_block, write_counter_block, info_block);

        Description = get_param(char(Outport(i, 1)), 'Description');
        info_block = {char('Outport'), char(name), char('Description'), char(Description)};
        [table_block, write_counter_block] = write_table_block(table_block, write_counter_block, info_block);

        AttributesFormatString = get_param(char(Outport(i, 1)), 'AttributesFormatString');
%         if strcmp(AttributesFormatString, '') == 0
%             AttributesFormatString = strrep(AttributesFormatString, '%', '%%');
%         end
        info_block = {char('Outport'), char(name), char('AttributesFormatString'), char(AttributesFormatString)};
        [table_block, write_counter_block] = write_table_block(table_block, write_counter_block, info_block);
    end

%     num = size(Terminator, 1);
%     for i = 1:num
%         [path, name] = com_split_path(char(Terminator(i, 1)));
%         if strcmp(name, 'Terminator')
%             name = strcat(name, '_DefaultName');
%         end
%         info_block = {char('Terminator'), char(name), '', ''};
%         [table_block, write_counter_block] = write_table_block(table_block, write_counter_block, info_block);
%     end
% 
%     num = size(Ground, 1);
%     for i = 1:num
%         [path, name] = com_split_path(char(Ground(i, 1)));
%         if strcmp(name, 'Ground')
%             name = strcat(name, '_DefaultName');
%         end
%         info_block = {char('Ground'), char(name), '', ''};
%         [table_block, write_counter_block] = write_table_block(table_block, write_counter_block, info_block);
%     end
% 
%     num = size(Convert, 1);
%     for i = 1:num
%         [path, name] = com_split_path(char(Convert(i, 1)));
%         ConvertRealWorld = get_param(char(Convert(i, 1)), 'ConvertRealWorld');
%         info_block = {char('DataTypeConversion'), char(name), char('ConvertRealWorld'), char(ConvertRealWorld)};
%         [table_block, write_counter_block] = write_table_block(table_block, write_counter_block, info_block);
% 
% %         RndMeth = get_param(char(Convert(i, 1)), 'RndMeth');
% %         info_block = {char('DataTypeConversion'), char(name), char('RndMeth'), char(RndMeth)};
% %         [table_block, write_counter_block] = write_excel_block(table_block, write_counter_block, info_block);
%     end
% 
%     num = size(Constant, 1);
%     for i = 1:num
%         [path, name] = com_split_path(char(Constant(i, 1)));
%         if strcmp(name, 'Constant')
%             name = strcat(name, '_DefaultName');
%         end
%         OutDataTypeStr = get_param(char(Constant(i, 1)), 'OutDataTypeStr');
%         info_block = {char('Constant'), char(name), char('OutDataTypeStr'), char(OutDataTypeStr)};
%         [table_block, write_counter_block] = write_table_block(table_block, write_counter_block, info_block);
% 
% %         Value = get_param(char(Constant(i, 1)), 'Value');
% %         info_block = {char('Constant'), char(name), char('Value'), char(Value)};
% %         [table_block, write_counter_block] = write_excel_block(table_block, write_counter_block, info_block);
%     end
% 
%     num = size(BusSelector, 1);
%     for i = 1:num
%         [path, name] = com_split_path(char(BusSelector(i, 1)));
%         Ports = get_param(char(BusSelector(i, 1)), 'Ports');
%         Ports_1 = num2str(Ports(1,1));
%         Ports_2 = num2str(Ports(1,2));
%         Ports_str = [Ports_1,',',Ports_2];
%         info_block = {char('BusSelector'), char(name), char('Ports'), char(Ports_str)};
%         [table_block, write_counter_block] = write_table_block(table_block, write_counter_block, info_block);
% 
% %         OutputSignals = get_param(char(BusSelector(i, 1)), 'OutputSignals');
% %         info_block = {char('BusSelector'), char(name), char('OutputSignals'), char(OutputSignals)};
% %         [table_block, write_counter_block] = write_excel_block(table_block, write_counter_block, info_block);
%     end
% 
%     num = size(BusCreator, 1);
%     for i = 1:num
%         [path, name] = com_split_path(char(BusCreator(i, 1)));
%         Ports = get_param(char(BusCreator(i, 1)), 'Ports');
%         Ports_1 = num2str(Ports(1,1));
%         Ports_2 = num2str(Ports(1,2));
%         Ports_str = [Ports_1,',',Ports_2];
%         info_block = {char('BusCreator'), char(name), char('Ports'), char(Ports_str)};
%         [table_block, write_counter_block] = write_table_block(table_block, write_counter_block, info_block);
% 
% %         OutDataTypeStr = get_param(char(BusCreator(i, 1)), 'OutDataTypeStr');
% %         info_block = {char('BusCreator'), char(name), char('OutDataTypeStr'), char(OutDataTypeStr)};
% %         [table_block, write_counter_block] = write_excel_block(table_block, write_counter_block, info_block);
%     end
% 
%     num = size(Goto, 1);
%     for i = 1:num
%         [path, name] = com_split_path(char(Goto(i, 1)));
%         GotoTag = get_param(char(Goto(i, 1)), 'GotoTag');
%         info_block = {char('Goto'), char(name), char('GotoTag'), char(GotoTag)};
%         [table_block, write_counter_block] = write_table_block(table_block, write_counter_block, info_block);
%     end
% 
%     num = size(From, 1);
%     for i = 1:num
%         [path, name] = com_split_path(char(From(i, 1)));
%         GotoTag = get_param(char(From(i, 1)), 'GotoTag');
%         info_block = {char('From'), char(name), char('GotoTag'), char(GotoTag)};
%         [table_block, write_counter_block] = write_table_block(table_block, write_counter_block, info_block);
%     end
% 
%     num = size(Mux, 1);
%     for i = 1:num
%         [path, name] = com_split_path(char(Mux(i, 1)));
%         if strcmp(name, 'Mux')
%             name = strcat(name, '_DefaultName');
%         end
%         Ports = get_param(char(Mux(i, 1)), 'Ports');
%         Ports_1 = num2str(Ports(1,1));
%         Ports_2 = num2str(Ports(1,2));
%         Ports_str = [Ports_1,',',Ports_2];
%         info_block = {char('Mux'), char(name), char('Inputs'), char(Ports_1)};
%         [table_block, write_counter_block] = write_table_block(table_block, write_counter_block, info_block);
% 
% %         OutDataTypeStr = get_param(char(Mux(i, 1)), 'OutDataTypeStr');
% %         info_block = {char('Mux'), char(name), char('OutDataTypeStr'), char(OutDataTypeStr)};
% %         [table_block, write_counter_block] = write_excel_block(table_block, write_counter_block, info_block);
%     end
% 
%     num = size(Selector, 1);
%     for i = 1:num
%         [path, name] = com_split_path(char(Selector(i, 1)));
%         if strcmp(name, 'Selector')
%             name = strcat(name, '_DefaultName');
%         end
% 
%         AttributesFormatString = get_param(char(Selector(i, 1)), 'AttributesFormatString');
%         info_block = {char('Selector'), char(name), char('AttributesFormatString'), char(AttributesFormatString)};
%         [table_block, write_counter_block] = write_table_block(table_block, write_counter_block, info_block);
% 
%         IndexMode = get_param(char(Selector(i, 1)), 'IndexMode');
%         info_block = {char('Selector'), char(name), char('IndexMode'), char(IndexMode)};
%         [table_block, write_counter_block] = write_excel_block(table_block, write_counter_block, info_block);
%
%         InputPortWidth = get_param(char(Selector(i, 1)), 'InputPortWidth');
%         info_block = {char('Selector'), char(name), char('InputPortWidth'), char(InputPortWidth)};
%         [table_block, write_counter_block] = write_excel_block(table_block, write_counter_block, info_block);
%
%         IndexOptions = get_param(char(Selector(i, 1)), 'IndexOptions');
%         info_block = {char('Selector'), char(name), char('IndexOptions'), char(IndexOptions)};
%         [table_block, write_counter_block] = write_excel_block(table_block, write_counter_block, info_block);
%
%         Indices = get_param(char(Selector(i, 1)), 'Indices');
%         info_block = {char('Selector'), char(name), char('Indices'), char(Indices)};
%         [table_block, write_counter_block] = write_excel_block(table_block, write_counter_block, info_block);
%
%         OutputSizes = get_param(char(Selector(i, 1)), 'OutputSizes');
%         info_block = {char('Selector'), char(name), char('OutputSizes'), char(OutputSizes)};
%         [table_block, write_counter_block] = write_excel_block(table_block, write_counter_block, info_block);
%     end
% 
%     num = size(Line, 1);
%     for i = 1:num
%         srcblock = get_param(Line(i, 1), 'SrcBlock');
%         srcport = get_param(Line(i, 1), 'SrcPort');
%         dstblock = get_param(Line(i, 1), 'DstBlock');
%         dstport = get_param(Line(i, 1), 'DstPort');
%         line_name = get_param(Line(i, 1), 'Name');
%
%         if (strcmp(srcblock, 'Terminator') == 1)...
%             || (strcmp(srcblock, 'Ground') == 1)...
%             || (strcmp(srcblock, 'Constant') == 1)...
%             || (strcmp(srcblock, 'Mux') == 1)...
%             || (strcmp(srcblock, 'Selector') == 1)
%             srcblock = strcat(srcblock, '_DefaultName');
%         end
%         if (strcmp(dstblock, 'Terminator') == 1)...
%             || (strcmp(dstblock, 'Ground') == 1)...
%             || (strcmp(dstblock, 'Constant') == 1)...
%             || (strcmp(dstblock, 'Mux') == 1)...
%             || (strcmp(dstblock, 'Selector') == 1)
%             dstblock = strcat(dstblock, '_DefaultName');
%         end
%
%         for j = 1 : size(table_block,1)
%             if strcmp( table_block{j,BlockTableNameIndex},srcblock ) == 1
%                 srcblock_type = table_block{j,BlockTableTypeIndex};
%             elseif strcmp( table_block{j,BlockTableNameIndex},dstblock ) == 1
%                     dstblock_type = table_block{j,BlockTableTypeIndex};
%             end
%
%         end
%
%         info_line = {char(srcblock), char(srcport), char(srcblock_type),char(dstblock), char(dstport),char(dstblock_type),char(line_name)};
%         [table_line, write_counter_line] = write_table_line(table_line, write_counter_line, info_line);
%     end
end

function portNamesList = getPortNames(portNamesStruct)

    portNamesList = '';
    fieldList = fieldnames(portNamesStruct);

    for i = 1 : size(fieldList)
        portName = getfield(portNamesStruct, fieldList{i});
        portNamesList{i} = char(portName);
    end

end

function [table_block_added, write_counter_block_next] = write_table_block(table_block, write_counter_block, info_block)

    table_block_added = [table_block; info_block];
    write_counter_block_next = write_counter_block + 1;

end

function [table_line_added, write_counter_line_next] = write_table_line(table_line, write_counter_line, info_line)

    table_line_added = [table_line; info_line];
    write_counter_line_next = write_counter_line + 1;

end
