function [title, table] = com_read_excel_group_xlsx(filePath)

    global SlGroupIndex
    global SlSignalNameIndex
    
    excelColumnFirstIndex = 'D';
    excelColumnLastIndex = 'E';
    excelLineTitleIndex = 3;
    excelLineFirstIndex = 4;
    excelLineLastIndex = 1000;

    excelReadRange = strcat(excelColumnFirstIndex, num2str(excelLineTitleIndex), ':', excelColumnLastIndex, num2str(excelLineTitleIndex));
    [title_num, title_txt, title_raw] = xlsread(filePath, 'GroupInfo', excelReadRange);
    title = title_raw;

    excelReadRange = strcat(excelColumnFirstIndex, num2str(excelLineFirstIndex), ':', excelColumnLastIndex, num2str(excelLineLastIndex));
    [table_num, table_txt, table_raw] = xlsread(filePath, 'GroupInfo', excelReadRange);
    table = '';
    tableIndex = 1;
    for i = 1 : size(table_raw, 1)
        if isnan(table_raw{i, SlGroupIndex})
            break;
        end
        table{tableIndex, SlGroupIndex}         = table_raw{i, SlGroupIndex};
        table{tableIndex, SlSignalNameIndex}	= table_raw{i, SlSignalNameIndex};
        tableIndex = tableIndex + 1;
    end

end
