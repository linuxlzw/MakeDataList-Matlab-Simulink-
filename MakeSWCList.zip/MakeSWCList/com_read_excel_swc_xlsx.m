function [title, table] = com_read_excel_swc_xlsx(filePath)

    global BlockTypeIndex
    global PortIndex
    global BlockNameIndex
    global OutDataTypeStrIndex
    global PortDimensionsIndex
    global DescriptionIndex
    global AttributesFormatStringIndex
    
    excelColumnFirstIndex = 'A';
    excelColumnLastIndex = 'G';
    excelLineTitleIndex = 1;
    excelLineFirstIndex = 2;
    excelLineLastIndex = 1000;
    
    excelReadRange = strcat(excelColumnFirstIndex, num2str(excelLineTitleIndex), ':', excelColumnLastIndex, num2str(excelLineTitleIndex));
    [title_num, title_txt, title_raw] = xlsread(filePath, 'PortList', excelReadRange);
    title = title_raw;
    
    excelReadRange = strcat(excelColumnFirstIndex, num2str(excelLineFirstIndex), ':', excelColumnLastIndex, num2str(excelLineLastIndex));
    [table_num, table_txt, table_raw] = xlsread(filePath, 'PortList', excelReadRange);
    table = '';
    tableIndex = 1;
    for i = 1 : size(table_raw, 1)
        if isnan(table_raw{i, BlockTypeIndex})
            break;
        end

        table{tableIndex, BlockTypeIndex}                       = table_raw{i, BlockTypeIndex};

        if isnumeric(table_raw{i, PortIndex}) == true
            table{tableIndex, PortIndex}                        = num2str(table_raw{i, PortIndex});
        else
            table{tableIndex, PortIndex}                        = table_raw{i, PortIndex};
        end

        table{tableIndex, BlockNameIndex}                       = table_raw{i, BlockNameIndex};

        table{tableIndex, OutDataTypeStrIndex}                  = table_raw{i, OutDataTypeStrIndex};

        if isnumeric(table_raw{i, PortDimensionsIndex}) == true
            table{tableIndex, PortDimensionsIndex}              = num2str(table_raw{i, PortDimensionsIndex});
        else
            table{tableIndex, PortDimensionsIndex}              = table_raw{i, PortDimensionsIndex};
        end

        if DescriptionIndex <= size(table_raw, 2)
            if isnan(table_raw{i, DescriptionIndex}) == true
                table{tableIndex, DescriptionIndex}             = '';
            elseif isnumeric(table_raw{i, DescriptionIndex}) == true
                table{tableIndex, DescriptionIndex}             = num2str(table_raw{i, DescriptionIndex});
            else
                table{tableIndex, DescriptionIndex}             = table_raw{i, DescriptionIndex};
            end
        else
            table{tableIndex, DescriptionIndex}                 = '';
        end

        if AttributesFormatStringIndex <= size(table_raw, 2)
            if isnan(table_raw{i, AttributesFormatStringIndex}) == true
                table{tableIndex, AttributesFormatStringIndex}  = '';
            elseif isnumeric(table_raw{i, AttributesFormatStringIndex}) == true
                table{tableIndex, AttributesFormatStringIndex}  = num2str(table_raw{i, AttributesFormatStringIndex});
            else
                table{tableIndex, AttributesFormatStringIndex}  = table_raw{i, AttributesFormatStringIndex};
            end
        else
            table{tableIndex, AttributesFormatStringIndex}      = '';
        end

        tableIndex = tableIndex + 1;
    end

end
