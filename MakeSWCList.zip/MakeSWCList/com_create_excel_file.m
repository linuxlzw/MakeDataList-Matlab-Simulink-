function com_create_excel_file(filePath, sheetName)

    if exist(filePath, 'file')
        delete(filePath);
    end

    try
        Excel = actxGetRunningServer('Excel.Application');
    catch
        Excel = actxserver('Excel.Application'); 
    end

    Workbooks = Excel.Workbooks;
    
    if exist(char(filePath), 'file') == 0
        Workbook = invoke(Workbooks, 'Add');
        invoke(Workbook, 'SaveAs', char(filePath));
        Sheets = Workbook.Sheets;
        index = 1;
        Sheets.Item(index).Name = sheetName;
        while true
            Count = Sheets.Count;
            if index <= Count
                if strcmp(Sheets.Item(index).Name, sheetName) == 0
                    Sheets.Item(index).Delete;
                else
                    index = index + 1;
                end
            else
                break;
            end
        end
        Workbook.Save;
        Workbook.Close;
    else
        error('%s is already exist', char(filePath));
    end

    Excel.Quit;

end