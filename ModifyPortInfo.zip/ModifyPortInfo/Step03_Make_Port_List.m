function Step03_Make_Port_List()

    global BlockTableTypeIndex
    global BlockTableNameIndex
    global BlockTableParamNameIndex
    global BlockTableParamValueIndex

    global BlockTypeIndex
    global PortIndex
    global BlockNameIndex
    global OutDataTypeStrIndex
    global PortDimensionsIndex
    global DescriptionIndex
    global AttributesFormatStringIndex

    BlockTableTypeIndex = 1;
    BlockTableNameIndex = 2;
    BlockTableParamNameIndex = 3;
    BlockTableParamValueIndex = 4;

    BlockTypeIndex = 1;
    PortIndex = 2;
    BlockNameIndex = 3;
    OutDataTypeStrIndex = 4;
    PortDimensionsIndex = 5;
    DescriptionIndex = 6;
    AttributesFormatStringIndex = 7;

    workPath = pwd;
    modelListPathName = strcat(workPath, '\ModelList.csv');
    modelList = com_read_excel_model_list(modelListPathName);
    inportXlsxPathName = strcat(workPath, '\InportListAll.xlsx');
    outportXlsxPathName = strcat(workPath, '\OutportListAll.xlsx');
    allPortXlsxPathName = strcat(workPath, '\AllPortListAll.xlsx');

    portListRowMax = 2000;
    portListColMax = 7; % BlockTypeIndex ~ AttributesFormatStringIndex
    inportListAllTemp = cell(portListRowMax, portListColMax);
    outportListAllTemp = cell(portListRowMax, portListColMax);
    allPortListAllTemp = cell(portListRowMax, portListColMax);
    inportListRowIndex = 0;
    outportListRowIndex = 0;
    allPortListRowIndex = 0;
    for i = 1 : portListRowMax
        for j = 1 : portListColMax
            inportListAllTemp{i, j} = '';
            outportListAllTemp{i, j} = '';
            allPortListAllTemp{i, j} = '';
        end
    end

    for i = 1 : size(modelList, 1)
        info = sprintf('[Info][%d/%d]Copy port list of ''%s''', i, size(modelList, 1), modelList{i, 1});
        disp(info);
        if strcmp(modelList{i, 3}, '1') == 1
            swcXlsxPathName = strcat(workPath, '\', modelList{i, 1}, '.xlsx');
            [paramName, inportInfoTable, outportInfoTable, allPortInfoTable] = Copy_Port_Info(swcXlsxPathName, modelList{i, 1});

            inportListStartIndex = inportListRowIndex + 1;
            inportListEndIndex = inportListRowIndex + size(inportInfoTable, 1);
            inportListAllTemp(inportListStartIndex : inportListEndIndex, :) = inportInfoTable;
            inportListRowIndex = inportListEndIndex;

            outportListStartIndex = outportListRowIndex + 1;
            outportListEndIndex = outportListRowIndex + size(outportInfoTable, 1);
            outportListAllTemp(outportListStartIndex : outportListEndIndex, :) = outportInfoTable;
            outportListRowIndex = outportListEndIndex;
            
            allPortListStartIndex = allPortListRowIndex + 1;
            allPortListEndIndex = allPortListRowIndex + size(allPortInfoTable, 1);
            allPortListAllTemp(allPortListStartIndex : allPortListEndIndex, :) = allPortInfoTable;
            allPortListRowIndex = allPortListEndIndex;
        else
            info = sprintf('[Info][%d/%d]Omit to copy port list of ''%s'' since DoExport flag is OFF in ModelList.csv', i, size(modelList, 1), modelList{i, 1});
            disp(info);
        end
    end

    inportListAll = inportListAllTemp(1:inportListRowIndex, :);
    outportListAll = outportListAllTemp(1:outportListRowIndex, :);
    allPortListAll = allPortListAllTemp(1:allPortListRowIndex, :);
    com_write_excel_port_list(inportXlsxPathName, inportListAll);
    com_write_excel_port_list(outportXlsxPathName, outportListAll);
    com_write_excel_port_list(allPortXlsxPathName, allPortListAll);

end

function [paramName, inportInfoTable, outportInfoTable, allPortInfoTable] = Copy_Port_Info(swcXlsxPathName, swcFolderName)

    global BlockTypeIndex
    global PortIndex
    global BlockNameIndex
    global OutDataTypeStrIndex
    global PortDimensionsIndex
    global DescriptionIndex
    global AttributesFormatStringIndex

    inportInfoTable = '';
    outportInfoTable = '';
    allPortInfoTable = '';
    inportInfoTableIndex = 0;
    outportInfoTableIndex = 0;
    allPortInfoTableIndex = 0;

    [paramName, swcPortInfoTable] = com_read_excel_swc_xlsx(swcXlsxPathName);
    swcNo = swcFolderName(1, 1:10); %SWC_xx_xx_

    for i = 1 : size(swcPortInfoTable, 1)
        if strcmp(swcPortInfoTable{i, BlockTypeIndex}, 'Inport') == 1
            inportInfoTableIndex = inportInfoTableIndex + 1;
            inportInfoTable{inportInfoTableIndex, BlockTypeIndex}                       = strcat(swcNo, swcPortInfoTable{i, BlockTypeIndex});
            inportInfoTable{inportInfoTableIndex, PortIndex}                            = swcPortInfoTable{i, PortIndex};
            inportInfoTable{inportInfoTableIndex, BlockNameIndex}                       = swcPortInfoTable{i, BlockNameIndex};
            inportInfoTable{inportInfoTableIndex, OutDataTypeStrIndex}                  = swcPortInfoTable{i, OutDataTypeStrIndex};
            inportInfoTable{inportInfoTableIndex, PortDimensionsIndex}                  = swcPortInfoTable{i, PortDimensionsIndex};
            inportInfoTable{inportInfoTableIndex, DescriptionIndex}                     = swcPortInfoTable{i, DescriptionIndex};
            inportInfoTable{inportInfoTableIndex, AttributesFormatStringIndex}          = swcPortInfoTable{i, AttributesFormatStringIndex};
        end
        if strcmp(swcPortInfoTable{i, BlockTypeIndex}, 'Outport') == 1
            outportInfoTableIndex = outportInfoTableIndex + 1;
            outportInfoTable{outportInfoTableIndex, BlockTypeIndex}                     = strcat(swcNo, swcPortInfoTable{i, BlockTypeIndex});
            outportInfoTable{outportInfoTableIndex, PortIndex}                          = swcPortInfoTable{i, PortIndex};
            outportInfoTable{outportInfoTableIndex, BlockNameIndex}                     = swcPortInfoTable{i, BlockNameIndex};
            outportInfoTable{outportInfoTableIndex, OutDataTypeStrIndex}                = swcPortInfoTable{i, OutDataTypeStrIndex};
            outportInfoTable{outportInfoTableIndex, PortDimensionsIndex}                = swcPortInfoTable{i, PortDimensionsIndex};
            outportInfoTable{outportInfoTableIndex, DescriptionIndex}                   = swcPortInfoTable{i, DescriptionIndex};
            outportInfoTable{outportInfoTableIndex, AttributesFormatStringIndex}        = swcPortInfoTable{i, AttributesFormatStringIndex};
        end
        if strcmp(swcPortInfoTable{i, BlockTypeIndex}, 'Inport') == 1 || strcmp(swcPortInfoTable{i, BlockTypeIndex}, 'Outport') == 1
            allPortInfoTableIndex = allPortInfoTableIndex + 1;
            allPortInfoTable{allPortInfoTableIndex, BlockTypeIndex}                     = strcat(swcNo, swcPortInfoTable{i, BlockTypeIndex});
            allPortInfoTable{allPortInfoTableIndex, PortIndex}                          = swcPortInfoTable{i, PortIndex};
            allPortInfoTable{allPortInfoTableIndex, BlockNameIndex}                     = swcPortInfoTable{i, BlockNameIndex};
            allPortInfoTable{allPortInfoTableIndex, OutDataTypeStrIndex}                = swcPortInfoTable{i, OutDataTypeStrIndex};
            allPortInfoTable{allPortInfoTableIndex, PortDimensionsIndex}                = swcPortInfoTable{i, PortDimensionsIndex};
            allPortInfoTable{allPortInfoTableIndex, DescriptionIndex}                   = swcPortInfoTable{i, DescriptionIndex};
            allPortInfoTable{allPortInfoTableIndex, AttributesFormatStringIndex}        = swcPortInfoTable{i, AttributesFormatStringIndex};
        end
    end

end
