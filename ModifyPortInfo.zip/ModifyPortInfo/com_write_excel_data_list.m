function com_write_excel_data_list(filePath, table)

    sheetName = 'DataList';
    com_create_excel_file(filePath, sheetName);

    titleRow = 1;
    titleCol = 1;
    titleFixColEnd = 6;
    titleDynColEnd = 1;
    for i = titleFixColEnd : size(table, 2)
        titleInfo = char(regexp(table{1, i}, '^SWC_', 'match'));
        if strcmp(titleInfo, '') == 0
            titleDynColEnd = i - 1;
            break;
        end
    end
    titleSwcCol = size(table, 2) - titleDynColEnd;
    excelWriteRange = makeCellRange(titleRow, size(table, 1), titleCol, size(table, 2));
    [status, message] = xlswrite(char(filePath), table, sheetName, excelWriteRange);

    try
        Excel = actxGetRunningServer('Excel.Application');
    catch
        Excel = actxserver('Excel.Application'); 
    end

    Workbooks = Excel.Workbooks;
    if exist(char(filePath), 'file')
        Workbook = invoke(Workbooks, 'Open', char(filePath));
        Sheets = Excel.ActiveWorkBook.Sheets;

        titleFixRange = makeCellRange(titleRow, titleRow, titleCol, titleFixColEnd);
        titleDynRange = makeCellRange(titleRow, titleRow, titleFixColEnd + 1, titleDynColEnd);
        titleSwcRange = makeCellRange(titleRow, titleRow, titleDynColEnd + 1, size(table, 2));
        dataFixRange = makeCellRange(titleRow + 1, size(table, 1), titleCol, titleFixColEnd);
        dataDynRange = makeCellRange(titleRow + 1, size(table, 1), titleFixColEnd + 1, titleDynColEnd);
        dataSwcRange = makeCellRange(titleRow + 1, size(table, 1), titleDynColEnd + 1, size(table, 2));
        colFixRange = makeColumnRange(titleCol, titleFixColEnd);
        colDynRange = makeColumnRange(titleFixColEnd + 1, titleDynColEnd);
        colSwcRange = makeColumnRange(titleDynColEnd + 1, size(table, 2));
        Sheets.Item(sheetName).Range(titleFixRange).Interior.Color = 65535; %BGR:00FFFF
        Sheets.Item(sheetName).Range(titleFixRange).HorizontalAlignment = -4108; %xlCenter -4108 ����
        Sheets.Item(sheetName).Range(titleFixRange).VerticalAlignment = -4108; %xlCenter -4108 ����
        Sheets.Item(sheetName).Range(titleDynRange).Interior.Color = 16751052; %BGR:FF99CC
        Sheets.Item(sheetName).Range(titleDynRange).HorizontalAlignment = -4108; %xlCenter -4108 ����
        Sheets.Item(sheetName).Range(titleDynRange).VerticalAlignment = -4108; %xlCenter -4108 ����
        Sheets.Item(sheetName).Range(titleSwcRange).Interior.Color = 13434828; %BGR:CCFFCC
        Sheets.Item(sheetName).Range(titleSwcRange).HorizontalAlignment = -4108; %xlCenter -4108 ����
        Sheets.Item(sheetName).Range(titleSwcRange).VerticalAlignment = -4108; %xlCenter -4108 ����
        Sheets.Item(sheetName).Range(titleSwcRange).WrapText = true;
        Sheets.Item(sheetName).Range(dataSwcRange).Font.Color = 16750848; %BGR:FF9900
        Sheets.Item(sheetName).Range(dataSwcRange).Font.Bold = true;
        Sheets.Item(sheetName).Range(dataSwcRange).HorizontalAlignment = -4108; %xlCenter -4108 ����
        Sheets.Item(sheetName).Range(dataSwcRange).VerticalAlignment = -4108; %xlCenter -4108 ����
        Sheets.Item(sheetName).Range(colFixRange).EntireColumn.AutoFit;
        Sheets.Item(sheetName).Range(colDynRange).EntireColumn.AutoFit;
        Sheets.Item(sheetName).Range(colSwcRange).ColumnWidth= 10;

        % Excel �J���җp���t�@�����X 
        % XlBordersIndex �� 
        % �擾����r�����w�肵�܂��B
        % ���O �l ���� 
        % xlDiagonalDown 5 �͈͓��̊e�Z���̍��������E���ւ̌r�� 
        % xlDiagonalUp 6 �͈͓��̊e�Z���̍���������E��ւ̌r�� 
        % xlEdgeBottom 9 �͈͓��̉����̌r�� 
        % xlEdgeLeft 7 �͈͓��̍��[�̌r�� 
        % xlEdgeRight 10 �͈͓��̉E�[�̌r�� 
        % xlEdgeTop 8 �͈͓��̏㑤�̌r�� 
        % xlInsideHorizontal 12 �͈͊O�̌r���������A�͈͓��̂��ׂẴZ���̐����r�� 
        % xlInsideVertical 11 �͈͊O�̌r���������A�͈͓��̂��ׂẴZ���̐����r�� 
        xlEdgeTop = 8;
        xlEdgeBottom = 9;
        xlEdgeLeft = 7;
        xlEdgeRight = 10;
        xlInsideVertical = 11;
        xlInsideHorizontal = 12;
        Sheets.Item(sheetName).Range(excelWriteRange).Borders.Item(xlEdgeTop).Color = 0;
        Sheets.Item(sheetName).Range(excelWriteRange).Borders.Item(xlEdgeBottom).Color = 0;
        Sheets.Item(sheetName).Range(excelWriteRange).Borders.Item(xlEdgeLeft).Color = 0;
        Sheets.Item(sheetName).Range(excelWriteRange).Borders.Item(xlEdgeRight).Color = 0;
        Sheets.Item(sheetName).Range(excelWriteRange).Borders.Item(xlInsideVertical).Color = 0;
        Sheets.Item(sheetName).Range(excelWriteRange).Borders.Item(xlInsideHorizontal).Color = 0;
        Sheets.Item(sheetName).Range(excelWriteRange).AutoFilter;

        index = 1;
        while true
            Count = Excel.ActiveWorkbook.Sheets.Count;
            if index <= Count
                if strcmp(Sheets.Item(index).Name, sheetName) == 0
                    Sheets.Item(index).Delete;
                else
                    index = index + 1;
                end
            else
                break;
            end
        end
    end

    Excel.ActiveWorkbook.Save; 
    Excel.ActiveWorkbook.Close;
    Excel.Quit;

end

function cellRange = makeCellRange(rowBegin, rowEnd, colBegin, colEnd)

    startCol = '';
    if colBegin >= 1 && colBegin <= 26         % A-Z
        startCol = char('A' + (colBegin -1));
    elseif colBegin >= 27 && colBegin <= 702   % AA-ZZ
        endCol1 = char('A' + (floor((colBegin -1) / 26) -1));
        endCol2 = char('A' + mod((colBegin -1), 26));
        startCol = strcat(endCol1, endCol2);
    else
        errorInfo = sprintf('[ErrorInfo(1)]makeCellRange: colBegin(%d) is invalid', colBegin);
        disp(errorInfo);
    end

    startRow = num2str(rowBegin);

    endCol = '';
    if colEnd >= 1 && colEnd <= 26         % A-Z
        endCol = char('A' + (colEnd -1));
    elseif colEnd >= 27 && colEnd <= 702   % AA-ZZ
        endCol1 = char('A' + (floor((colEnd -1) / 26) -1));
        endCol2 = char('A' + mod((colEnd -1), 26));
        endCol = strcat(endCol1, endCol2);
    else
        errorInfo = sprintf('[ErrorInfo(2)]makeCellRange: colEnd(%d) is invalid', colEnd);
        disp(errorInfo);
    end

    endRow = num2str(rowEnd);

    cellRange = strcat(startCol, startRow, ':', endCol, endRow);
end

function columnRange = makeColumnRange(colBegin, colEnd)

    startCol = '';
    if colBegin >= 1 && colBegin <= 26         % A-Z
        startCol = char('A' + (colBegin -1));
    elseif colBegin >= 27 && colBegin <= 702   % AA-ZZ
        endCol1 = char('A' + (floor((colBegin -1) / 26) -1));
        endCol2 = char('A' + mod((colBegin -1), 26));
        startCol = strcat(endCol1, endCol2);
    else
        errorInfo = sprintf('[ErrorInfo(1)]makeColumnRange: colBegin(%d) is invalid', colBegin);
        disp(errorInfo);
    end

    endCol = '';
    if colEnd >= 1 && colEnd <= 26         % A-Z
        endCol = char('A' + (colEnd -1));
    elseif colEnd >= 27 && colEnd <= 702   % AA-ZZ
        endCol1 = char('A' + (floor((colEnd -1) / 26) -1));
        endCol2 = char('A' + mod((colEnd -1), 26));
        endCol = strcat(endCol1, endCol2);
    else
        errorInfo = sprintf('[ErrorInfo(2)]makeColumnRange: colEnd(%d) is invalid', colEnd);
        disp(errorInfo);
    end

    columnRange = strcat(startCol, ':', endCol);
end
