function com_modify_port_info(folderPath, modelName)

    global BlockTableTypeIndex
    global BlockTableNameIndex
    global BlockTableParamNameIndex
    global BlockTableParamValueIndex

    global BlockTypeIndex
    global PortIndex
    global BlockNameIndex
    global OutDataTypeStrIndex
    global PortDimensionsIndex
    global DescriptionIndex
    global AttributesFormatStringIndex

    BlockTableTypeIndex = 1;
    BlockTableNameIndex = 2;
    BlockTableParamNameIndex = 3;
    BlockTableParamValueIndex = 4;

    BlockTypeIndex = 1;
    PortIndex = 2;
    BlockNameIndex = 3;
    OutDataTypeStrIndex = 4;
    PortDimensionsIndex = 5;
    DescriptionIndex = 6;
    AttributesFormatStringIndex = 7;

    [path_notused, folderName] = com_split_path(folderPath);
    workPath = pwd;
    modelPathName = strcat(folderPath, '/', modelName, '.slx');
    xlsxPathName = strcat(workPath, '/', folderName, '.xlsx');

    com_clean_env(modelName);

    [paramName, portInfoTable] = com_read_excel_swc_xlsx(xlsxPathName);
    open_system(modelPathName);
    Modify_ModelData(modelName, paramName, portInfoTable);

    close_system(modelPathName, 1);

end

function Modify_ModelData(modelName, paramName, portInfoTable)

    global BlockTypeIndex
    global PortIndex
    global BlockNameIndex
    global OutDataTypeStrIndex
    global PortDimensionsIndex
    global DescriptionIndex
    global AttributesFormatStringIndex

    portList_Line = '';

    inportList = find_system(char(modelName), 'SearchDepth', '1', 'IncludeCommented', 'on', 'blocktype', 'Inport');
    outportList = find_system(char(modelName), 'SearchDepth', '1', 'IncludeCommented', 'on', 'blocktype', 'Outport');

    portListRowMax = size(inportList, 1) + size(outportList, 1);
    portListColMax = 3; % BlockTypeIndex, PortIndex, BlockNameIndex
    portList = cell(portListRowMax, portListColMax);
    portListRowIndex = 0;
    for i = 1 : portListRowMax
        for j = 1 : portListColMax
            portList{i, j} = '';
        end
    end

    for i = 1 : size(inportList, 1)

        portList_Line{BlockTypeIndex} = 'Inport';
        portList_Line{PortIndex} = get_param(inportList{i}, 'Port');
        [path_notused, name] = com_split_path(inportList{i});
        portList_Line{BlockNameIndex} = name;
        portListRowIndex = portListRowIndex + 1;
        portList(portListRowIndex, :) = portList_Line;

    end

    for i = 1 : size(outportList, 1)

        portList_Line{BlockTypeIndex} = 'Outport';
        portList_Line{PortIndex} = get_param(outportList{i}, 'Port');
        [path_notused, name] = com_split_path(outportList{i});
        portList_Line{BlockNameIndex} = name;
        portListRowIndex = portListRowIndex + 1;
        portList(portListRowIndex, :) = portList_Line;

    end

    for i = 1 : size(portInfoTable, 1)

        for j = 1 : size(portList, 1)

            if strcmp(portInfoTable{i, BlockTypeIndex}, portList{j, BlockTypeIndex}) == 1 ...
                    && strcmp(portInfoTable{i, PortIndex}, portList{j, PortIndex}) == 1
                blockName = sprintf('%s/%s', modelName, portList{j, BlockNameIndex});
                set_param(blockName, paramName{OutDataTypeStrIndex}, portInfoTable{i, OutDataTypeStrIndex});
                set_param(blockName, paramName{PortDimensionsIndex}, portInfoTable{i, PortDimensionsIndex});
                set_param(blockName, paramName{DescriptionIndex}, portInfoTable{i, DescriptionIndex});
                set_param(blockName, paramName{AttributesFormatStringIndex}, portInfoTable{i, AttributesFormatStringIndex});
                set_param(blockName, paramName{BlockNameIndex}, portInfoTable{i, BlockNameIndex});
                break;
            end

        end

    end

end
