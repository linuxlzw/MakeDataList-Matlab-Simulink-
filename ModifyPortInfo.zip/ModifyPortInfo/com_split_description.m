function itemNameAndContents = com_split_description(descInfo)

    itemNameAndContents = '';
    items = strsplit(descInfo, '\n');
    for i = 1 : size(items, 2)
        itemNameAndContents = [itemNameAndContents; strsplit(items{i}, ':')];
    end
    itemNameAndContents = itemNameAndContents.'; %transpose

end
