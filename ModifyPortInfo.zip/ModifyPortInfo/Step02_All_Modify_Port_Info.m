function Step02_All_Modify_Port_Info()

    workPath = pwd;
    modelListPathName = strcat(workPath, '\ModelList.csv');
    modelList = com_read_excel_model_list(modelListPathName);

    for i = 1 : size(modelList, 1)
        info = sprintf('[Info][%d/%d]Modifying ''%s''\t''%s''', i, size(modelList, 1), modelList{i, 1}, modelList{i, 2});
        disp(info);
        if strcmp(modelList{i, 4}, '1') == 1
            com_modify_port_info(strcat('../../', modelList{i, 1}), modelList{i, 2});
        else
            info = sprintf('[Info][%d/%d]Omit to modify ''%s''\t''%s'' since DoModify flag is OFF in ModelList.csv', i, size(modelList, 1), modelList{i, 1}, modelList{i, 2});
            disp(info);
        end
    end

end
