function table = com_read_excel_model_list(filePath)

    fp = fopen(char(filePath), 'r');
    tline = fgetl(fp);
    table = '';

    while ~feof(fp)
        tline = fgetl(fp);
        table = [table; strsplit(char(tline), {'',','})];
    end

    fclose(fp);

end