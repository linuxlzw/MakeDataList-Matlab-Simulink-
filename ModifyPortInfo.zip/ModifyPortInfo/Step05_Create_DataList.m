function Step05_Create_DataList()

    global BlockTableTypeIndex
    global BlockTableNameIndex
    global BlockTableParamNameIndex
    global BlockTableParamValueIndex

    global BlockTypeIndex
    global PortIndex
    global BlockNameIndex
    global OutDataTypeStrIndex
    global PortDimensionsIndex
    global DescriptionIndex
    global AttributesFormatStringIndex

%     global DlIDIndex
%     global DlQmAsilIndex
%     global DlDataNameIndex
%     global DlNameIndex
%     global DlDataTypeIndex
%     global DlDataDimensionIndex    
    global DlIDIndex
    global DlNameIndex
    global DlDataTypeIndex
    global DlDataDimensionIndex
    global DlQmAsilIndex

    BlockTableTypeIndex = 1;
    BlockTableNameIndex = 2;
    BlockTableParamNameIndex = 3;
    BlockTableParamValueIndex = 4;

    BlockTypeIndex = 1;
    PortIndex = 2;
    BlockNameIndex = 3;
    OutDataTypeStrIndex = 4;
    PortDimensionsIndex = 5;
    DescriptionIndex = 6;
    AttributesFormatStringIndex = 7;

    DlIDIndex = 2;
    DlNameIndex = 3;
    DlDataTypeIndex = 4;
    DlDataDimensionIndex = 5;
    DlQmAsilIndex = 6;

    workPath = pwd;
    modelListPathName = strcat(workPath, '\ModelList.csv');
    modelList = com_read_excel_model_list(modelListPathName);
    outportXlsxPathName = strcat(workPath, '\OutportListAll.xlsx');
    [paramName, outportListAll] = com_read_excel_swc_xlsx(outportXlsxPathName);
    inportXlsxPathName = strcat(workPath, '\InportListAll.xlsx');
    [paramName, inportListAll] = com_read_excel_swc_xlsx(inportXlsxPathName);
    dataListXlsxPathName = strcat(workPath, '\SoftwareArchitectureDesign_DataList.xlsx');

    dataListTable = Create_DataList_Architecture(modelList, outportListAll, inportListAll);

    for i = 1 : size(modelList, 1)
        info = sprintf('[Info][%d/%d]Write IN/OUT info of ''%s'' to DataList', i, size(modelList, 1), modelList{i, 1});
        disp(info);
        if strcmp(modelList{i, 3}, '1') == 1
            swcXlsxPathName = strcat(workPath, '\', modelList{i, 1}, '.xlsx');
            dataListTable = Write_In_Out_Info(modelList{i, 1}, swcXlsxPathName, dataListTable);
        else
            info = sprintf('[Info][%d/%d]Omit to write IN/OUT info of ''%s'' to DataList since DoExport flag is OFF in ModelList.csv', i, size(modelList, 1), modelList{i, 1});
            disp(info);
        end
    end

    com_write_excel_data_list(dataListXlsxPathName, dataListTable);

    info = sprintf('[Info]Create ''%s'' complete! ', dataListXlsxPathName);
    disp(info);

end

function dataListTable = Create_DataList_Architecture(modelList, outportListAll, inportListAllOrg)

    global BlockTypeIndex
    global PortIndex
    global BlockNameIndex
    global OutDataTypeStrIndex
    global PortDimensionsIndex
    global DescriptionIndex
    global AttributesFormatStringIndex

    global DlIDIndex
    global DlNameIndex
    global DlDataTypeIndex
    global DlDataDimensionIndex
    global DlQmAsilIndex

    titleFixPart = {
                '', ...
                'ID', ...
                'Name(Implement)', ...
                'DataType', ...
                'DataDimension', ...
                'QM/ASIL' ...
            };
    titleDynPart = '';

    sortColNum = 3;
    inportListAllExt = cell(size(inportListAllOrg, 1), size(inportListAllOrg, 2));
    inportListAllExtRowNum = 0;
    for i = 1 : size(inportListAllOrg, 1)
        IDMatchData = regexp(inportListAllOrg{i, BlockNameIndex}, '^D\d{6}', 'match');
        if isempty(IDMatchData) == true
            inportListAllExtRowNum = inportListAllExtRowNum + 1;
            inportListAllExt(inportListAllExtRowNum, :) = inportListAllOrg(i, :);
        end
    end
    inportListAllExtSorted = inportListAllExt(1 : inportListAllExtRowNum, :);
    inportListAllExtSorted = sortrows(inportListAllExtSorted, sortColNum);

    inportListAllExtSortedUnduplicated = cell(size(inportListAllExtSorted, 1), size(inportListAllExtSorted, 2));
    inportListAllExtSortedUnduplicatedRowNum = 0;
    preInportListAllRow = cell(1, size(inportListAllExtSorted, 2));
    for i = 1 : size(inportListAllExtSorted, 1)
%         if strcmp(inportListAllExtSorted{i, PortDimensionsIndex}, '-1') == 1
%             inportListAllExtSorted{i, PortDimensionsIndex} = '1';
%         end
        if strcmp(preInportListAllRow{1, BlockNameIndex}, inportListAllExtSorted{i, BlockNameIndex}) == 0 ...
                || strcmp(preInportListAllRow{1, OutDataTypeStrIndex}, inportListAllExtSorted{i, OutDataTypeStrIndex}) == 0 ...
                || strcmp(preInportListAllRow{1, PortDimensionsIndex}, inportListAllExtSorted{i, PortDimensionsIndex}) == 0
            inportListAllExtSortedUnduplicatedRowNum = inportListAllExtSortedUnduplicatedRowNum + 1;
            inportListAllExtSortedUnduplicated(inportListAllExtSortedUnduplicatedRowNum, :) = inportListAllExtSorted(i, :);
            preInportListAllRow = inportListAllExtSortedUnduplicated(inportListAllExtSortedUnduplicatedRowNum, :);
        end
    end
    inportListAll = inportListAllExtSortedUnduplicated(1 : inportListAllExtSortedUnduplicatedRowNum, :);

    portListAll = [outportListAll; inportListAll];

    dynPartRowMax = size(portListAll, 1);
    dynPartColMax = 50;
    dynPartRowNum = dynPartRowMax;
    dynPartColNum = 1;
    dynPart = cell(dynPartRowMax, dynPartColMax);
    for i = 1 : dynPartRowMax
        for j = 1 : dynPartColMax
            dynPart{i, j} = '';
        end
    end

    dynPartRowTitle = portListAll(:, BlockNameIndex);
    %dynPartRowTitle = outportListAll(:, BlockNameIndex);
    dynPartColTitle = cell(1, dynPartColMax);
    for i = 1 : dynPartColMax
        dynPartColTitle{1, i} = '';
    end

    descInfoAll = portListAll(:, DescriptionIndex);
    %descInfoAll = outportListAll(:, DescriptionIndex);
    for i = 1 : size(descInfoAll, 1)
        try
            itemNameAndContents = com_split_description(descInfoAll{i});
        catch
            error('[ErrorInfo(1)]Description is error since there are too many ":" in the comment below!\nBlockType=''%s''\nPortIndex=''%s''\nBlockName=''%s''\nDescription=\n''%s''\n', portListAll{i, BlockTypeIndex}, portListAll{i, PortIndex}, portListAll{i, BlockNameIndex}, portListAll{i, DescriptionIndex});
        end
        if size(itemNameAndContents, 1) == 2
            for j = 1 : size(itemNameAndContents, 2)
                itemName = itemNameAndContents{1, j};
                itemContents = itemNameAndContents{2, j};
                for k = 1 : dynPartColMax
                    if strcmp(dynPartColTitle{1, k}, itemName) == 1
                        dynPart{i, k} = itemContents;
                        break;
                    else
                        if strcmp(dynPartColTitle{1, k}, '') == 1
                            dynPartColTitle{1, k} = itemName;
                            dynPart{i, k} = itemContents;
                            dynPartColNum = k;
                            break;
                        end
                    end
                end
            end
        end
    end

    titleDynPart = dynPartColTitle(1, 1 : dynPartColNum);
    contentsDynPart = dynPart(:, 1 : dynPartColNum);

    titleSwcCol = modelList(:, 1).'; %transpose
    title = [titleFixPart, titleDynPart, titleSwcCol];

    dataListTable = cell((size(title, 1) + size(portListAll, 1)), size(title, 2));
    for i = 1 : size(dataListTable, 1)
        for j = 1 : size(dataListTable, 2)
            dataListTable{i, j} = '';
        end
    end

    dataListTable(1, :) = title;

    descColNumUpperCase = 0;
    descColNumLowerCase = 0;
    for i = 1 : size(titleDynPart, 2)
        if strcmp(titleDynPart{1, i}, 'Description') == 1
            descColNumUpperCase = i;
        end
        if strcmp(titleDynPart{1, i}, 'description') == 1
            descColNumLowerCase = i;
        end
    end

    for i = 1 : size(portListAll, 1)
        j = i + 1;
        IDMatchData = regexp(portListAll{i, BlockNameIndex}, '^D\d{6}', 'match');

        if isempty(IDMatchData) == false
            dataListTable{j, DlIDIndex} = IDMatchData{1, 1};
            dataListTable{j, DlNameIndex} = portListAll{i, BlockNameIndex}(9 : size(portListAll{i, BlockNameIndex}, 2));
        else
            position = strfind(portListAll{i, BlockNameIndex}, '_');
            if isempty(position) == false
                dataListTable{j, DlIDIndex} = portListAll{i, BlockNameIndex}(1 : position - 1);
                dataListTable{j, DlNameIndex} = portListAll{i, BlockNameIndex}(position + 1 : size(portListAll{i, BlockNameIndex}, 2));
            else
                dataListTable{j, DlIDIndex} = 'No ID';
                dataListTable{j, DlNameIndex} = portListAll{i, BlockNameIndex};
            end
        end

%         dataListTable{j, DlDataNameIndex} = portListAll{i, BlockNameIndex};
%         if descColNumUpperCase ~= 0
%             if strcmp(contentsDynPart{i, descColNumUpperCase}, '') == 0
%                 dataListTable{j, DlDataNameIndex} = contentsDynPart{i, descColNumUpperCase};
%             end
%         end
%         if descColNumLowerCase ~= 0
%             if strcmp(contentsDynPart{i, descColNumLowerCase}, '') == 0
%                 dataListTable{j, DlDataNameIndex} = contentsDynPart{i, descColNumLowerCase};
%             end
%         end

        dataListTable{j, DlDataTypeIndex} = portListAll{i, OutDataTypeStrIndex};
        dataListTable{j, DlDataDimensionIndex} = portListAll{i, PortDimensionsIndex};
        if strcmp(dataListTable{j, DlDataDimensionIndex}, '-1') == 1
            dataListTable{j, DlDataDimensionIndex} = '1';
        end
    end

    dynPartAll = [titleDynPart; contentsDynPart];
    dataListTable(:, size(titleFixPart, 2) + 1 : size(titleFixPart, 2) + dynPartColNum) = dynPartAll;

end

function dataListTable = Write_In_Out_Info(swcName, swcXlsxPathName, dataListTable)

    global BlockTypeIndex
    global PortIndex
    global BlockNameIndex
    global OutDataTypeStrIndex
    global PortDimensionsIndex
    global DescriptionIndex
    global AttributesFormatStringIndex

    global DlIDIndex
    global DlNameIndex
    global DlDataTypeIndex
    global DlDataDimensionIndex
    global DlQmAsilIndex

    titleRowNum = 1;
    swcColNum = 0;
    [paramName, portInfoTable] = com_read_excel_swc_xlsx(swcXlsxPathName);

    for i = 1 : size(dataListTable, 2)
        if strcmp(swcName, dataListTable{titleRowNum, i}) == 1
            swcColNum = i;
            break;
        end
    end

    if swcColNum ~= 0
        for i = 1 : size(portInfoTable, 1)
            if strcmp(portInfoTable{i, PortDimensionsIndex}, '-1') == 1
                portInfoTable{i, PortDimensionsIndex} = '1';
            end
            findFlag = false;
            for j = 1 + titleRowNum : size(dataListTable, 1)
                if strcmp(dataListTable{j, DlIDIndex}, 'No ID') == 1
                    dataListTableName = dataListTable{j, DlNameIndex};
                else
                    dataListTableName = sprintf('%s%s%s', dataListTable{j, DlIDIndex}, '_', dataListTable{j, DlNameIndex});
                end
                
                if strcmp(portInfoTable{i, BlockNameIndex}, dataListTableName) == 1 ...
                        && strcmp(portInfoTable{i, OutDataTypeStrIndex}, dataListTable{j, DlDataTypeIndex}) == 1 ...
                        && strcmp(portInfoTable{i, PortDimensionsIndex}, dataListTable{j, DlDataDimensionIndex}) == 1
                    findFlag = true;
                    if strcmp(dataListTable{j, swcColNum}, '') == 1
                        if strcmp(portInfoTable{i, BlockTypeIndex}, 'Inport') == 1
                            dataListTable{j, swcColNum} = 'IN';
                        elseif strcmp(portInfoTable{i, BlockTypeIndex}, 'Outport') == 1
                            dataListTable{j, swcColNum} = 'OUT';
                        else
                            dataListTable{j, swcColNum} = 'DATA_LIST_ERROR';
                        end
                    else
                        if strcmp(portInfoTable{i, BlockTypeIndex}, 'Inport') == 1
                            dataListTable{j, swcColNum} = strcat(dataListTable{j, swcColNum}, '/IN');
                        elseif strcmp(portInfoTable{i, BlockTypeIndex}, 'Outport') == 1
                            dataListTable{j, swcColNum} = strcat(dataListTable{j, swcColNum}, '/OUT');
                        else
                            dataListTable{j, swcColNum} = strcat(dataListTable{j, swcColNum}, '/DATA_LIST_ERROR');
                        end
                    end
                end
            end
            if findFlag == false
                error('[ErrorInfo(2)]There is no PortName ''%s'' from ''%s'' in DataList.\n\t%s\t%s\t%s', portInfoTable{i, BlockNameIndex}, swcName, portInfoTable{i, BlockNameIndex}, portInfoTable{i, OutDataTypeStrIndex}, portInfoTable{i, PortDimensionsIndex});
            end
        end
    else
        error('[ErrorInfo(3)]There is no column ''%s'' in DataList', swcName);
    end

end

