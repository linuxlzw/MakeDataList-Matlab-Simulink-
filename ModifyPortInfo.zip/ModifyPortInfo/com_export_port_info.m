function com_export_port_info(folderPath, modelName, xlsxNamePreFix)

    global BlockTableTypeIndex
    global BlockTableNameIndex
    global BlockTableParamNameIndex
    global BlockTableParamValueIndex

    global BlockTypeIndex
    global PortIndex
    global BlockNameIndex
    global OutDataTypeStrIndex
    global PortDimensionsIndex
    global DescriptionIndex
    global AttributesFormatStringIndex

    BlockTableTypeIndex = 1;
    BlockTableNameIndex = 2;
    BlockTableParamNameIndex = 3;
    BlockTableParamValueIndex = 4;

    BlockTypeIndex = 1;
    PortIndex = 2;
    BlockNameIndex = 3;
    OutDataTypeStrIndex = 4;
    PortDimensionsIndex = 5;
    DescriptionIndex = 6;
    AttributesFormatStringIndex = 7;

    [path_notused, folderName] = com_split_path(folderPath);
    workPath = pwd;
    modelPathName = strcat(folderPath, '/', modelName, '.slx');
    xlsxPathName = strcat(workPath, '\', xlsxNamePreFix, folderName, '.xlsx');

    com_clean_env(modelName);

    load_system(modelPathName);
    isLib = 0;
    subsys = get_subsys(modelName, isLib);
    exportPortInfoTable = Export_ModelData(modelPathName, subsys, isLib);

    if exist(xlsxPathName, 'file')
        [paramName, portInfoTableBefore] = com_read_excel_swc_xlsx(xlsxPathName);
        isChangedFlag = com_judge_port_info_change(portInfoTableBefore, exportPortInfoTable);
        if strcmp(isChangedFlag, 'TRUE') == 1
            com_write_excel_port_list(xlsxPathName, exportPortInfoTable);
        else
            info = sprintf('[Info]Omit to write excel file for model ''%s''\t''%s'' since all ports info have not been changed.', folderName, modelName);
            disp(info);
        end
    else
        com_write_excel_port_list(xlsxPathName, exportPortInfoTable);
    end

    close_system(modelPathName);

end

function subsys = get_subsys(sysName, isLib)
    if isLib == 1
        sys = find_system(char(sysName), 'LookUnderMasks', 'on', 'FollowLinks', 'on', 'blocktype', 'SubSystem');
        subsys = [];
    else
        sys = find_system(char(sysName), 'LookUnderMasks', 'on', 'blocktype', 'SubSystem');
        subsys = sysName;
    end
    num = size(sys, 1);
    for i = 1:num
        if strcmp('', get_param(char(sys(i, 1)), 'ReferenceBlock')) == 1
            subsys = [subsys; sys(i, 1)];
        end
    end
    num = size(subsys, 1);%num = 1
    if num == 1
        tmp = char(subsys);
        subsys = [];
        subsys{1, 1} = char(tmp);
    end
end

function exportPortInfoTable = Export_ModelData(modelPathName, subsys, isLib)

    num = 1;
    for i = 1: num
         exportPortInfoTable = Export_ModelPortInfo(modelPathName, subsys(i, 1), isLib);
    end

end

function exportPortList = Export_ModelPortInfo(modelPathName, model_path, isLib)

    global BlockTableTypeIndex
    global BlockTableNameIndex
    global BlockTableParamNameIndex
    global BlockTableParamValueIndex

    global BlockTypeIndex
    global PortIndex
    global BlockNameIndex
    global OutDataTypeStrIndex
    global PortDimensionsIndex
    global DescriptionIndex
    global AttributesFormatStringIndex

    [table_block, table_line, ModelReferenceInputList, ModelReferenceOutputList, ModelReferenceList, ModelReference_Name] = com_get_block_table_and_line_table(model_path, isLib);

    exportPortListIndex = 0;
    portName = '';

    for i = 1 : size(table_block, 1)
        if strcmp(table_block{i, BlockTableTypeIndex}, 'Inport') == 1 ...
                || strcmp(table_block{i, BlockTableTypeIndex}, 'Outport') == 1
            if strcmp(table_block{i, BlockTableNameIndex}, portName) == 0
                exportPortListIndex = exportPortListIndex + 1;
                portName = table_block{i, BlockTableNameIndex};

                exportPortList{exportPortListIndex, BlockTypeIndex} = table_block{i, BlockTableTypeIndex};
                exportPortList{exportPortListIndex, BlockNameIndex} = table_block{i, BlockTableNameIndex};
            end

            switch table_block{i, BlockTableParamNameIndex}
                case 'Port'
                    exportPortList{exportPortListIndex, PortIndex} = table_block{i, BlockTableParamValueIndex};
                case 'OutDataTypeStr'
                    exportPortList{exportPortListIndex, OutDataTypeStrIndex} = table_block{i, BlockTableParamValueIndex};
                case 'PortDimensions'
                    exportPortList{exportPortListIndex, PortDimensionsIndex} = table_block{i, BlockTableParamValueIndex};
                case 'Description'
                    exportPortList{exportPortListIndex, DescriptionIndex} = table_block{i, BlockTableParamValueIndex};
                case 'AttributesFormatString'
                    exportPortList{exportPortListIndex, AttributesFormatStringIndex} = table_block{i, BlockTableParamValueIndex};
                otherwise
                    % No action
            end
        end
    end

    %%%%%%%%%% For local test %%%%%%%%%%
    if exist('Local_Test_DataList.ctx', 'file') == 2
        for exportPortListIndex = 1 : size(exportPortList, 1)
            if strcmp(exportPortList{exportPortListIndex, BlockTypeIndex}, 'Outport') == 1
                dataIDPartOld = char(regexp(modelPathName, 'SWC_\d{2}_\d{2}', 'match'));
                if strcmp(dataIDPartOld, '') == 0
                    dataIDPart = strcat('D', dataIDPartOld(5:6), dataIDPartOld(8:9));
                    if str2num(exportPortList{exportPortListIndex, PortIndex}) < 10
                        dataIDPart = strcat(dataIDPart, '0', exportPortList{exportPortListIndex, PortIndex}, '_');
                    else
                        dataIDPart = strcat(dataIDPart, exportPortList{exportPortListIndex, PortIndex}, '_');
                    end
                end

                matchFlag = 0;
                if matchFlag == 0
                    nonNamePartOld = char(regexp(exportPortList{exportPortListIndex, BlockNameIndex}, '^D\d{2}_\d{2}_\d{2}_', 'match'));
                    if strcmp(nonNamePartOld, '') == 0
                        matchFlag = 1;
                    end
                end
                if matchFlag == 0
                    nonNamePartOld = char(regexp(exportPortList{exportPortListIndex, BlockNameIndex}, '^D\d{6}_', 'match'));
                    if strcmp(nonNamePartOld, '') == 0
                        matchFlag = 1;
                    end
                end
                if matchFlag == 0
                    nonNamePartOld = char(regexp(exportPortList{exportPortListIndex, BlockNameIndex}, '^D[x]*_', 'match'));
                    if strcmp(nonNamePartOld, '') == 0
                        matchFlag = 1;
                    end
                end
                if matchFlag == 0
                    nonNamePartOld = char(regexp(exportPortList{exportPortListIndex, BlockNameIndex}, '^ID\d{3,4}_', 'match'));
                    if strcmp(nonNamePartOld, '') == 0
                        matchFlag = 1;
                    end
                end

                if matchFlag == 0
                    exportPortList{exportPortListIndex, BlockNameIndex} = strcat(dataIDPart, exportPortList{exportPortListIndex, BlockNameIndex});
                else
                    exportPortList{exportPortListIndex, BlockNameIndex} = strrep(exportPortList{exportPortListIndex, BlockNameIndex}, nonNamePartOld, dataIDPart);
                end
            end
        end
    end
    %%%%%%%%%% For local test %%%%%%%%%%

end
