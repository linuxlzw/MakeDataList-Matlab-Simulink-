function com_clean_env(modelName)

    close_system(modelName, 0);
    fclose('all');

end