function [path, name] = com_split_path(model_path)
    items = strsplit(char(model_path), '/');
    num = size(items, 2);
    name = char(items(1, num));
    path = char(items(1, 1));
    for i = 2:num -1
        path = sprintf('%s/%s', char(path), char(items(1, i)));
    end
end
