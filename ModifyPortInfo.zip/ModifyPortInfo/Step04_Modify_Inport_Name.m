function Step04_Modify_Inport_Name()

    global BlockTableTypeIndex
    global BlockTableNameIndex
    global BlockTableParamNameIndex
    global BlockTableParamValueIndex

    global BlockTypeIndex
    global PortIndex
    global BlockNameIndex
    global OutDataTypeStrIndex
    global PortDimensionsIndex
    global DescriptionIndex
    global AttributesFormatStringIndex

    BlockTableTypeIndex = 1;
    BlockTableNameIndex = 2;
    BlockTableParamNameIndex = 3;
    BlockTableParamValueIndex = 4;

    BlockTypeIndex = 1;
    PortIndex = 2;
    BlockNameIndex = 3;
    OutDataTypeStrIndex = 4;
    PortDimensionsIndex = 5;
    DescriptionIndex = 6;
    AttributesFormatStringIndex = 7;

    workPath = pwd;
    modelListPathName = strcat(workPath, '\ModelList.csv');
    modelList = com_read_excel_model_list(modelListPathName);
    outportXlsxPathName = strcat(workPath, '\OutportListAll.xlsx');
    [paramName, outportListAll] = com_read_excel_swc_xlsx(outportXlsxPathName);

    for i = 1 : size(modelList, 1)
        info = sprintf('[Info][%d/%d]Modify inport name of ''%s''', i, size(modelList, 1), modelList{i, 1});
        disp(info);
        if strcmp(modelList{i, 4}, '1') == 1
            modelName = modelList{i, 2};
            modelPath = strcat('../../', modelList{i, 1});
            swcXlsxPathName = strcat(workPath, '\', modelList{i, 1}, '.xlsx');
            swcXlsxPathNameBefore = strcat(workPath, '\', 'Before_', modelList{i, 1}, '.xlsx');
            com_export_port_info(modelPath, modelName, 'Before_');
            Modify_Inport_Name(modelPath, modelName, swcXlsxPathName, swcXlsxPathNameBefore, outportListAll);
        else
            info = sprintf('[Info][%d/%d]Omit to modify inport name of ''%s'' since DoModify flag is OFF in ModelList.csv', i, size(modelList, 1), modelList{i, 1});
            disp(info);
        end
    end

end

function Modify_Inport_Name(modelPath, modelName, swcXlsxPathName, swcXlsxPathNameBefore, outportListAll)

    global BlockTypeIndex
    global PortIndex
    global BlockNameIndex
    global OutDataTypeStrIndex
    global PortDimensionsIndex
    global DescriptionIndex
    global AttributesFormatStringIndex

    portIDBits = 7;
    modifyInportNameFlag = 'FALSE';

    [paramNameBefore, portInfoTableBefore] = com_read_excel_swc_xlsx(swcXlsxPathNameBefore);
    [paramName, portInfoTable] = com_read_excel_swc_xlsx(swcXlsxPathName);

    for i = 1 : size(portInfoTable, 1)
        BlockType = portInfoTable{i, BlockTypeIndex};
        if strcmp(BlockType, 'Inport') == 1
            inportNameMatchData = regexp(portInfoTable{i, BlockNameIndex}, '^D\d{6}', 'match');
            for j = 1 : size(outportListAll, 1)
                outportID = outportListAll{j, BlockNameIndex}(1:portIDBits);
                if strcmp(inportNameMatchData, outportID) == 1
                    portInfoTable{i, BlockNameIndex} = outportListAll{j, BlockNameIndex};
                    portInfoTable{i, OutDataTypeStrIndex} = outportListAll{j, OutDataTypeStrIndex};
                    portInfoTable{i, PortDimensionsIndex} = outportListAll{j, PortDimensionsIndex};
                    portInfoTable{i, DescriptionIndex} = outportListAll{j, DescriptionIndex};
                    portInfoTable{i, AttributesFormatStringIndex} = outportListAll{j, AttributesFormatStringIndex};
                    modifyInportNameFlag = 'TRUE';
                    break;
                end
            end
        end
    end

    %%%%%%%%%% For local test %%%%%%%%%%
    if exist('Local_Test_DataList.ctx', 'file') == 2
        for i = 1 : size(portInfoTable, 1)
            BlockType = portInfoTable{i, BlockTypeIndex};
            if strcmp(BlockType, 'Inport') == 1
                inportNameMatchData = regexp(portInfoTable{i, BlockNameIndex}, '^ID\d{3,4}_', 'match');
                if isempty(inportNameMatchData) == false
                    inportNamePart = portInfoTable{i, BlockNameIndex}((size(inportNameMatchData{1, 1}, 2) + 1) : size(portInfoTable{i, BlockNameIndex}, 2));
                    for j = 1 : size(outportListAll, 1)
                        outportNamePart = outportListAll{j, BlockNameIndex}(9 : size(outportListAll{j, BlockNameIndex}, 2));
                        if strcmpi(inportNamePart, outportNamePart) == 1
                            portInfoTable{i, BlockNameIndex} = outportListAll{j, BlockNameIndex};
                            portInfoTable{i, OutDataTypeStrIndex} = outportListAll{j, OutDataTypeStrIndex};
                            portInfoTable{i, PortDimensionsIndex} = outportListAll{j, PortDimensionsIndex};
                            portInfoTable{i, DescriptionIndex} = outportListAll{j, DescriptionIndex};
                            portInfoTable{i, AttributesFormatStringIndex} = outportListAll{j, AttributesFormatStringIndex};
                            modifyInportNameFlag = 'TRUE';
                            break;
                        end
                    end
                end

                inportNameMatchData = regexp(portInfoTable{i, BlockNameIndex}, '^ID\d{2}_\d{2}_\d{2}_', 'match');
                if isempty(inportNameMatchData) == false
                    inportNamePart = portInfoTable{i, BlockNameIndex}((size(inportNameMatchData{1, 1}, 2) + 1) : size(portInfoTable{i, BlockNameIndex}, 2));
                    for j = 1 : size(outportListAll, 1)
                        outportNamePart = outportListAll{j, BlockNameIndex}(9 : size(outportListAll{j, BlockNameIndex}, 2));
                        if strcmpi(inportNamePart, outportNamePart) == 1
                            portInfoTable{i, BlockNameIndex} = outportListAll{j, BlockNameIndex};
                            portInfoTable{i, OutDataTypeStrIndex} = outportListAll{j, OutDataTypeStrIndex};
                            portInfoTable{i, PortDimensionsIndex} = outportListAll{j, PortDimensionsIndex};
                            portInfoTable{i, DescriptionIndex} = outportListAll{j, DescriptionIndex};
                            portInfoTable{i, AttributesFormatStringIndex} = outportListAll{j, AttributesFormatStringIndex};
                            modifyInportNameFlag = 'TRUE';
                            break;
                        end
                    end
                end

                inportNamePart = portInfoTable{i, BlockNameIndex};
                for j = 1 : size(outportListAll, 1)
                    outportNamePart = outportListAll{j, BlockNameIndex}(9 : size(outportListAll{j, BlockNameIndex}, 2));
                    if strcmpi(inportNamePart, outportNamePart) == 1
                        portInfoTable{i, BlockNameIndex} = outportListAll{j, BlockNameIndex};
                        portInfoTable{i, OutDataTypeStrIndex} = outportListAll{j, OutDataTypeStrIndex};
                        portInfoTable{i, PortDimensionsIndex} = outportListAll{j, PortDimensionsIndex};
                        portInfoTable{i, DescriptionIndex} = outportListAll{j, DescriptionIndex};
                        portInfoTable{i, AttributesFormatStringIndex} = outportListAll{j, AttributesFormatStringIndex};
                        modifyInportNameFlag = 'TRUE';
                        break;
                    end
                end
            end
        end
    end
    %%%%%%%%%% For local test %%%%%%%%%%

    isChangedFlag = com_judge_port_info_change(portInfoTableBefore, portInfoTable);
    if strcmp(isChangedFlag, 'TRUE') == 1
        com_write_excel_port_list(swcXlsxPathName, portInfoTable);
        com_modify_port_info(modelPath, modelName);
    else
        info = sprintf('[Info]Omit to write excel file ''%s''\t''%s'' since all ports info have not been changed.', modelPath, modelName);
        disp(info);
    end

end
